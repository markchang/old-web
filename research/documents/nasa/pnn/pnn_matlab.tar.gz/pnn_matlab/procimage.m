% process data to do imaging

% load up data
clear
load data

image_data = reshape(data,4,512,512);

image_1 = reshape(image_data(1,:,:),512,512);
image_2 = reshape(image_data(2,:,:),512,512);
image_3 = reshape(image_data(3,:,:),512,512);
image_4 = reshape(image_data(4,:,:),512,512);

csum = image_1 + image_2 + image_3 + image_4;
composite = bitshift(255,24);
composite = bitor(bitshift(csum,16),composite);
composite = bitor(bitshift(csum,8),composite);
composite = bitor(csum,composite);
composite = bitcmp(composite,32);

colormap(gray);
imagesc(composite');
