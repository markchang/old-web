% please help me vectorize something like this:

load class;
load data;
