% parse.m

% parses the three input files:
% data.ascii, train.ascii, tinfo.ascii

% parse the training info (header)
load tinfo.ascii -ascii
bands        = tinfo(1);
patterns     = tinfo(2);
classes      = tinfo(3);
rows         = tinfo(4);
cols         = tinfo(5);

pattern_size = zeros(1,classes);
sigma        = zeros(1,classes);

pattern_size(1:classes) = tinfo(6); tinfo(8); tinfo(10); tinfo(12); tinfo(14);
sigma(1:classes)        = tinfo(7); tinfo(9); tinfo(11); tinfo(13); tinfo(15);

% create K1/K2 variables
k1 = 1./( (2*pi)^(bands/2) .* sigma.^bands .* pattern_size(1));
k2 = 1./(2.*sigma.^2);

clear tinfo
save tinfo

% parse the training data into class arrays
load train.ascii -ascii

for index=1:classes
  class(index,:) = train( (index-1)*bands*pattern_size(index) + 1 : index*pattern_size(index)*bands)';
end

clear train;
save class class;

load data.ascii -ascii;
save data data;
