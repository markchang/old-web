% pnn2.m
% perform pnn function
% VECTORIZED

% clean slate
clear

% load up the variables
load tinfo;
load class;
load data;

% reshape data
weights = reshape(class',bands,pattern_size(1),classes);

p = input('Which pixel ')
% load pixel to process
pixel = data( (p-1)*bands+1:p*bands);

% reshape pixel
pixels = reshape(pixel(:,ones(1,patterns)),bands,pattern_size(1),classes);

% do calculation
sim_res = sum( (pixels-weights).^2,1);

vec_res = k1(1).*sum(exp( -(k2(1).*sum((weights-pixels).^2)) ));
vec_ans = find(vec_res==max(vec_res))-1

% output important data
%sim_res(1,[1:3 398:400],1:5)

