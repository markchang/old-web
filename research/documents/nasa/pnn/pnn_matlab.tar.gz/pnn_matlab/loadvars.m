% loadvars.m

% loads up all variables

load tinfo
load class
load data
