/* convert.c
   parses a training file and image file
   --
   training file is composed of 32bit data written as INT32 from an
   Intel platform (little-Endian)

   <# of bands><# of patterns><# of classes><0x0000> <-- size info
   <weight_0><weight_1>......<weight_patterns*bands> <-- all the weights
   <class ID><# of patterns in class_ID><sigma_ID>   <-- one class
                         .
			 .
			 .
   <class ID><# of patterns in class_ID><sigma_ID>   <-- last class
   --
   data file is composed of header and data.  header is comprised of
   32-bit data, while image is 8-bit data.  unfortunately, like the
   training file, it was all written as 32-bit data in INT32 format
   on an Intel platform (little-Endian).  swapping nibbles is needed
   in the header, and reading the first 8-bits is fine enough for
   the actual image data.

   <header>
   <rows><cols><# of bands><bytes per entry> <-- assume b.p.e is 8
   *****************************************************************
   */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MCHECK(m)       if (!m) { fprintf(stderr, "malloc failed\n"); exit(1); }

typedef unsigned char byte;

/* color stuff */
char *color_names[10]={"gray",
		       "yellow",
		       "brown",
		       "green",
		       "blue",
		       "black",
		       "red",
		       "purple",
		       "white",
		       "pink"};
char *color_specs[10]={"#C0C0C0",
		       "#FFFF00",
		       "#800000",
		       "#008080",
		       "#0000FF",
		       "#000000",
		       "#FF0000",
		       "#8000FF",
		       "#FFFFFF",
		       "#FF00FF"};
enum {gray=128, yellow, brown, darkgreen, blue, black, red, purple, white, pink};
int cred[10] = {0xC0,0xFF,0x80,0x00,0x00,0x00,0xFF,0x80,0xFF,0xFF};
int cgrn[10] = {0xC0,0xFF,0x00,0x80,0x00,0x00,0x00,0x00,0xFF,0x00};
int cblu[10] = {0xC0,0x00,0x00,0x80,0xFF,0x00,0x00,0xFF,0xFF,0xFF};
int local_color[16];

/* prototypes */
int freadswap(FILE *fp);
void load_raw_data(char *filename);
void write_ascii(char *datafile, char *trainfile, char *tinfo);

/* structures */
struct Class {
  int num;
  int patterns;
  int sigma;
};

struct Data {
  int bands, patterns, num_classes;
  int rows, cols, imagefile_bands, bytes_per_entry;
  int max_weight;
  int *weights;
  int *pixels;
  int plength;
  struct Class *class;
};

typedef struct Class Class;
typedef struct Data Data;

/* globals */
Data data;

int main() {
  load_raw_data("image");
  write_ascii("data.ascii","train.ascii","tinfo.ascii");
  
  return 0;
}

/* writes data and training set to ascii matlab-compatible files */
void write_ascii(char *datafile, char *trainfile, char *tinfo)
{
  int pixel,i;
  FILE *outfile;

  /* open data file */
  outfile = fopen(datafile, "w");
  if( !outfile ) {
    printf("Error: can't open output file %s\n",datafile);
    exit(1);
  }

  /* output the data */
  printf("Writing image data to %s...\n",datafile);
  for( pixel=0; pixel < data.plength; pixel++ )
    fprintf(outfile, "%d\n",data.pixels[pixel]);

  fclose(outfile);

  /* open training file */
  outfile = fopen(trainfile, "w");
  if( !outfile ) {
    printf("Error: can't open output file %s\n",trainfile);
    exit(1);
  }

  /* output training data */
  printf("Writing training data to %s...\n",trainfile);
  for( pixel=0; pixel < data.max_weight ; pixel++ )
    fprintf(outfile, "%d\n",data.weights[pixel]);

  fclose(outfile);

  /* open training info file */
  outfile = fopen(tinfo, "w");
  if( !outfile ) {
    printf("Error: can't open output file %s\n",tinfo);
    exit(1);
  }

  /* output training info */
  printf("Writing training info to %s..\n",tinfo);
  fprintf(outfile, "%d\n", data.bands);
  fprintf(outfile, "%d\n", data.patterns);
  fprintf(outfile, "%d\n", data.num_classes);
  fprintf(outfile, "%d\n", data.rows);
  fprintf(outfile, "%d\n", data.cols);
  fprintf(outfile, "%d\n", data.num_classes);

  for(i=0; i<data.num_classes; i++ ) {
    fprintf(outfile, "%d\n", data.class[i].patterns);
    fprintf(outfile, "%d\n", data.class[i].sigma);
  }
  fclose(outfile);
}


/* loads the data from training and image files */
void load_raw_data(char *f)
{
  FILE *fp;
  int i,max,min;
  char filename[50];
  unsigned char *buffer;
  
  /* get the correct filename */
  sprintf(filename,"%s.trn",f);
  fp = fopen( filename,"r" );
  if( !fp ) {
    printf("Can't open %s\n",filename);
    exit(1);
  }
  
  /* read in the first three bytes of header info */
  data.bands = freadswap(fp);
  data.patterns = freadswap(fp);
  data.num_classes = freadswap(fp);
  
  data.max_weight = data.bands * data.patterns;
  
  /* test for end of header */
  if( freadswap(fp) != (int) 0 ) {
    printf("Training file error.  Fourth byte of header is not NULL\n");
    fclose(fp);
    exit(1);
  }

#ifdef DEBUG
  printf("Bands = %d, Patterns = %d, Num_classes = %d\n\n",data.bands,
	 data.patterns,data.num_classes);
#endif

  /* allocate some memory for the weights */
  data.weights = (int *)malloc(data.max_weight*sizeof(int));

  /* read in training data */
  for(i=0; i<data.max_weight; i++) {
    data.weights[i] = freadswap(fp);
  }

  /* allocate some memory for the classes */
  data.class = (Class *)malloc(data.num_classes*sizeof(Class));

  /* read in the classes */
  for(i=0; i<data.num_classes; i++) {
    data.class[i].num = freadswap(fp);
    data.class[i].patterns = freadswap(fp);
    data.class[i].sigma = freadswap(fp);
  }

  fclose(fp);

#ifdef DEBUG
  for(i=0; i<data.num_classes; i++) {
    printf("Class: %d patterns: %d sigma: %d\n",data.class[i].num,data.class[i].patterns,
	   data.class[i].sigma);
  }
  printf("Number of weights: %d\n\n",data.bands*data.patterns);
  printf("First six weights:\n");
  for(i=0;i<6;i++) {
    printf("0x%.2x\n",data.weights[i]);
  }
#endif

  /* now do the image file */
  sprintf(filename,"%s.dat",f);
  fp = fopen( filename,"r" );
  if( !fp ) {
    printf("Can't open %s\n",filename);
    exit(1);
  }

  /* process header */
  data.rows = freadswap(fp);
  data.cols = freadswap(fp);
  data.imagefile_bands = freadswap(fp);
  data.bytes_per_entry = freadswap(fp);

  /* number of pixels in the image */
  data.plength = data.rows * data.cols * data.imagefile_bands;

#ifdef DEBUG
  printf("\nrows x cols x bands = %d x %d x %d\n",data.rows,data.cols,data.imagefile_bands);
  printf("bytes per entry = %d\n",data.bytes_per_entry);

  printf("Reading image file...");
#endif
  /* allocate a buffer and read in the image file */
  buffer = (unsigned char *)malloc(data.plength*data.bytes_per_entry*sizeof(unsigned char));
  fread(buffer,sizeof(unsigned char),data.plength*data.bytes_per_entry,fp);
  fclose(fp);

  /* allocate a buffer for the pixels */
  data.pixels = (int *)malloc(data.plength*sizeof(int));
  /* stride the data in */
  max=0;
  min=0xFF;
  for(i=0; i<data.plength; i++) {
    data.pixels[i] = buffer[data.bytes_per_entry*i];
#ifdef DEBUG
    if( data.pixels[i] > max )
      max=data.pixels[i];
    if( data.pixels[i] < min )
      min=data.pixels[i];
#endif
  }

#ifdef DEBUG
  printf("MAX color: %d, MIN color: %d\n",max,min);
#endif

  /* free out the buffer */
  free(buffer);

#ifdef DEBUG
  printf("First six pixels:\n");
  for(i=0;i<6;i++) {
    printf("0x%.2x\n",data.pixels[i]);
  }
#endif
}

int freadswap(FILE *fp)
{
  unsigned char a,b,c,d;

  fscanf(fp,"%c",&a);
  fscanf(fp,"%c",&b);
  fscanf(fp,"%c",&c);
  fscanf(fp,"%c",&d);

  return ( (int) (d<<24)|(c<<16)|(b<<8)|(a) );
}

