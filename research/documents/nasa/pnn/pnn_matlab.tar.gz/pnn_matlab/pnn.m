% pnn.m
% perform pnn function

% clean slate
clear

% load up the variables
load tinfo;
load class;
load data;

% init results vector
results = zeros(size(data));

for p=1:rows*cols
   fprintf(1,'Pixel: %d\n',p);

   % load pixel to process
   pixel = data( (p-1)*bands+1:p*bands);

   class_total = zeros(classes,1);
   class_sum   = zeros(classes,1);

   % class loop
   for c=1:classes

      class_total(c) = 0;
      class_sum(c) = 0;

      % weight loop
      for w=1:bands:pattern_size(c)*bands-bands
	 weight = class(c,w:w+bands-1);
	 class_sum(c) = exp( -(k2(c)*sum( (pixel-weight').^2 ))) + class_sum(c);
      end

      class_total(c) = class_sum(c) * k1(c);
   end
   results(p) = find( class_total == max( class_total ) )-1;
end
