/* pnn.c
	The pnn algorithm. This version has been tested on Solaris 2.6.
	
	ASCII output version.

   Training file is composed of 32bit data written as INT32 from an
   Intel platform (little-Endian)

   <# of bands><# of patterns><# of classes><0x0000> <-- size info
   <weight_0><weight_1>......<weight_patterns*bands> <-- all the weights
   <class ID><# of patterns in class_ID><sigma_ID>   <-- one class
          .
			 .
			 .
   <class ID><# of patterns in class_ID><sigma_ID>   <-- last class
   --
   data file is composed of header and data.  header is comprised of
   32-bit data, while image is 8-bit data.  unfortunately, like the
   training file, it was all written as 32-bit data in INT32 format
   on an Intel platform (little-Endian).  swapping nibbles is needed
   in the header, and reading the first 8-bits is fine enough for
   the actual image data.

   <header>
   <rows><cols><# of bands><bytes per entry> <-- assume b.p.e is 8
   *****************************************************************
   */


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>
#include <math.h>

/* inline routine */
#define MCHECK(m)       if (!m) { fprintf(stderr, "malloc failed\n"); exit(0); }

/* types */
typedef unsigned char byte;
int *image;

/* ***********************
	Variables
	***********************
*/
/* structures */
struct Class {
  int num;
  int patterns;
  int sigma;
};

struct Data {
  int bands, patterns, num_classes;
  int rows, cols, imagefile_bands, bytes_per_entry;
  int max_weight;
  int *weights;
  int *pixels;
  int plength;
  struct Class *class;
};

typedef struct Class Class;
typedef struct Data Data;

/* globals */
Data data;

/* ************************************** FUNCTIONS *************************** */

/* returns a seed for srand based on the time */
unsigned int time_seed() {
  struct timeval t;
  struct timezone tzdummy;

  gettimeofday(&t, &tzdummy);
  return (unsigned int)(t.tv_usec);
}

/* write out the 'image' array to a file */
void write_results(char *filename)
{
  FILE *fp;
  int i;

  /* try and open the file */
  fp=fopen(filename,"w");
  if( !fp ) {
    printf("Error opening output file %s\n",filename);
    exit(1);
  }

  printf("Writing output file...%d bytes\n",data.rows*data.cols);
  /* non-ascii version */
  /* fwrite(image,sizeof(int),data.rows*data.cols,fp); */

  /* ascii output */
  for( i=0 ;i<data.rows*data.cols; i++ )
    fprintf(fp, "%d\n",image[i]);

  fclose(fp);
}

/* read 32bits and swap endian */
int freadswap(FILE *fp)
{
  unsigned char a,b,c,d;

  fscanf(fp,"%c",&a);
  fscanf(fp,"%c",&b);
  fscanf(fp,"%c",&c);
  fscanf(fp,"%c",&d);

  return ( (int) (d<<24)|(c<<16)|(b<<8)|(a) );
}

/* loads the data from training and image files */
void load_raw_data(char *f)
{
  FILE *fp;
  int i,max,min;
  char filename[50];
  unsigned char *buffer;
  
  /* get the correct filename */
  sprintf(filename,"%s.trn",f);
  fp = fopen( filename,"r" );
  if( !fp ) {
    printf("Can't open %s\n",filename);
    exit(1);
  }
  
  /* read in the first three bytes of header info */
  data.bands = freadswap(fp);
  data.patterns = freadswap(fp);
  data.num_classes = freadswap(fp);
  
  data.max_weight = data.bands * data.patterns;
  
  /* test for end of header */
  if( freadswap(fp) != (int) 0 ) {
    printf("Training file error.  Fourth byte of header is not NULL\n");
    fclose(fp);
    exit(1);
  }

#ifdef DEBUG
  printf("Bands = %d, Patterns = %d, Num_classes = %d\n\n",data.bands,
			data.patterns,data.num_classes);
#endif

  /* allocate some memory for the weights */
  data.weights = (int *)malloc(data.max_weight*sizeof(int));

  /* read in training data */
  for(i=0; i<data.max_weight; i++) {
    data.weights[i] = freadswap(fp);
  }

  /* allocate some memory for the classes */
  data.class = (Class *)malloc(data.num_classes*sizeof(Class));

  /* read in the classes */
  for(i=0; i<data.num_classes; i++) {
    data.class[i].num = freadswap(fp);
    data.class[i].patterns = freadswap(fp);
    data.class[i].sigma = freadswap(fp);
  }

  fclose(fp);

#ifdef DEBUG
  for(i=0; i<data.num_classes; i++) {
    printf("Class: %d patterns: %d sigma: %d\n",data.class[i].num,data.class[i].patterns,
			  data.class[i].sigma);
  }
  printf("Number of weights: %d\n\n",data.bands*data.patterns);
  printf("First six weights:\n");
  for(i=0;i<6;i++) {
    printf("0x%.2x\n",data.weights[i]);
  }
#endif

  /* now do the image file */
  sprintf(filename,"%s.dat",f);
  fp = fopen( filename,"r" );
  if( !fp ) {
    printf("Can't open %s\n",filename);
    exit(1);
  }

  /* process header */
  data.rows = freadswap(fp);
  data.cols = freadswap(fp);
  data.imagefile_bands = freadswap(fp);
  data.bytes_per_entry = freadswap(fp);

  /* number of pixels in the image */
  data.plength = data.rows * data.cols * data.imagefile_bands;

#ifdef DEBUG
  printf("\nrows x cols x bands = %d x %d x %d\n",data.rows,data.cols,data.imagefile_bands);
  printf("bytes per entry = %d\n",data.bytes_per_entry);

  printf("Reading image file...");
#endif

  /* allocate a buffer and read in the image file */
  buffer = (unsigned char *)malloc(data.plength*data.bytes_per_entry*sizeof(unsigned char));
  fread(buffer,sizeof(unsigned char),data.plength*data.bytes_per_entry,fp);
  fclose(fp);

  /* allocate a buffer for the pixels */
  data.pixels = (int *)malloc(data.plength*sizeof(int));
  /* stride the data in */
  max=0;
  min=0xFF;
  for(i=0; i<data.plength; i++) {
    data.pixels[i] = buffer[data.bytes_per_entry*i];
#ifdef DEBUG
    if( data.pixels[i] > max )
      max=data.pixels[i];
    if( data.pixels[i] < min )
      min=data.pixels[i];
#endif
  }

#ifdef DEBUG
  printf("MAX color: %d, MIN color: %d\n",max,min);
#endif

  /* free out the buffer */
  free(buffer);

#ifdef DEBUG
  printf("First six pixels:\n");
  for(i=0;i<6;i++) {
    printf("0x%.2x\n",data.pixels[i]);
  }
#endif

  /* allocate memory for image */
  image = (int *)malloc(sizeof(int)*data.rows*data.cols);
}


/* classifies using local floating-point algorithm... */
void pnn(void)
{
  double tmp, sigma_x, maxval_x, curval_x, term_x, exp_m_x,class_sum_x;
  double *tmpfl;
  int class, weight, diff, pix=0, start;
  int x, y, pattern, bands,i;
  long psum;

  printf("Beginning classification process of %d rows\n",data.rows);
  printf("Current row:\n");
  tmpfl = (double *)malloc(data.num_classes*sizeof(double));

  /* precompute some sigma-values */
  tmp = pow(2.0*M_PI, (data.bands/2.0) );
  for( class=0; class< data.num_classes; class++ ) {
    tmpfl[class] = tmp * pow(data.class[class].sigma, data.bands);
  }
  sigma_x = pow(data.class[--class].sigma,2);

  /* classify entire image, row by row */
  for (y = 0; y<data.rows; y++) {
    /* classify a row */
    start = (y*data.cols);
    for(x=start; x<(start+data.cols); x++) {	
      maxval_x = -1;
      weight=0;
      
      for(class=0; class<data.num_classes; class++) {
		  class_sum_x = 0;
	
		  for(pattern=0; pattern<data.class[class].patterns; pattern++) {
			 psum = 0;
	  
			 for(bands=0; bands<data.bands; bands++) {
				diff = data.pixels[pix+bands] - data.weights[weight++];
				psum += diff * diff;
			 } /* end of bands loop */

			 term_x = ((double)psum)/(2.0*sigma_x);
			 exp_m_x = exp(-term_x);
			 class_sum_x += exp_m_x;
	  
		  } /* end of pattern loop */

		  if (data.class[class].patterns == 0) {
			 curval_x = -1;
		  } 
		  else {
			 curval_x = class_sum_x / (tmpfl[class] * data.class[class].patterns);
		  }
	
		  /* assign color to pixel based on the largest class score. */
		  if (maxval_x < curval_x) {
			 maxval_x = curval_x;
			 image[x] = data.class[class].num;
		  } 
      } /* end of Class loop */
      pix += data.bands; /*  increment the raw data pixel "pointer" */
    } /* end of x (row) loop */
			
	 /* a row is finished -- print diagnostic info here if necessary */
	 printf("\r%d",y);
	 fflush(NULL);
  } /* end of y (entire image) block */
  printf("\n\nDone\n");
}

int main(int argc, char *argv[]) {
  /* Timing variables */
  struct timeval etstart, etstop;  /* Elapsed times using gettimeofday() */
  struct timezone tzdummy;
  clock_t etstart2, etstop2;       /* Elapsed times using times() */
  unsigned long long usecstart, usecstop;
  struct tms cputstart, cputstop;  /* CPU times for my processes */

  /* load data */
  printf("Loading input data...\n");
  load_raw_data("image");

  /* Start Clock */
  printf("Starting clock.\n");
  gettimeofday(&etstart, &tzdummy);
  etstart2 = times(&cputstart);

  pnn();

  /* Stop Clock */
  gettimeofday(&etstop, &tzdummy);
  etstop2 = times(&cputstop);
  printf("Stopped clock.\n");
  usecstart = (unsigned long long)etstart.tv_sec * 1000000 + etstart.tv_usec;
  usecstop = (unsigned long long)etstop.tv_sec * 1000000 + etstop.tv_usec;

  /* Display timing results */
  printf("\nElapsed time = %g ms.\n",
	 (float)(usecstop - usecstart)/(float)1000);
  printf("(CPU times are accurate to the nearest %g ms)\n",
	 1.0/(float)CLK_TCK * 1000.0);
  printf("My total CPU time for parent = %g ms.\n",
	 (float)( (cputstop.tms_utime + cputstop.tms_stime) -
		  (cputstart.tms_utime + cputstart.tms_stime) ) /
	 (float)CLK_TCK * 1000);
  printf("My system CPU time for parent = %g ms.\n",
	 (float)(cputstop.tms_stime - cputstart.tms_stime) /
	 (float)CLK_TCK * 1000);
  printf("My total CPU time for child processes = %g ms.\n",
	 (float)( (cputstop.tms_cutime + cputstop.tms_cstime) -
		  (cputstart.tms_cutime + cputstart.tms_cstime) ) /
	 (float)CLK_TCK * 1000);
  printf("--------------------------------------------\n");

  /* write output */
  write_results("output.ascii");

  return 0;
}

