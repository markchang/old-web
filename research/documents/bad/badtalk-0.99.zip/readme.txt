A Beginner's Guide to Bad Engineering Presentations

This work is licensed under a Creative Commons License and is
copyrighted © 2004 by Mark L. Chang and Katherine Compton.

Current version: 0.99 - June 22, 2004
(note: PDF version does not include some animations)

This presentation was created as a response to seeing some common things that
we didn't like in lots of engineering presentations. By no means is this a
complete guide, nor are our opinions really anything but our own opinions. Take
it mostly as "things that our advisor said to not do".

Please feel free to spread this around and give us feedback via email.

Mark (mchang @ ee.washington.edu)
Kati (kati @ engr.wisc.edu)

