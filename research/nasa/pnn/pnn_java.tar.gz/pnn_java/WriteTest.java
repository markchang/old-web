import java.io.*;

public class WriteTest {
  public static void main(String[] args) throws IOException {
    File outputFile = new File("output.raw");
    int pixels[] = new int[500];
    int i;

    for( i=0; i<500; i++)
      pixels[i]=i;

    FileOutputStream fs = new FileOutputStream(outputFile);
    for(i=0;i<500;i++)
      fs.write(pixels[i]);

    fs.close();
  }
}
