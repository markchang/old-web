/**
*	defines the colors for the pnn algorithm.	 The "inefficient" shifting of zeroes
*	will make it easier to change colors later if needed.
*/

public class pnnColors
{
  public int[] colors = new int[16];

  public pnnColors()
    {
      int opaque = 0xff<<24;
	
      /* grey - urban */
      colors[0] = opaque|(192<<16)|(192<<8)|192;

      /* Yellow - fields */
      colors[1] = opaque|(255<<16)|(255<<8)|0;

      /* Brown - range */
      colors[2] = opaque|(128<<16)|(0<<8)|0;

      /* Dark green - Forest */
      colors[3] = opaque|(0<<16)|(128<<8)|128;

      /* Blue - water */
      colors[4] = opaque|(0<<16)|(0<<8)|255;

      /* Wetland - black */
      colors[5] = opaque|(0<<16)|(0<<8)|0;

      /* Red - barren */
      colors[6] = opaque|(255<<16)|(0<<8)|0;

      /* Purple - Tundra */
      colors[7] = opaque|(128<<16)|(0<<8)|255;

      /* White - Perennial snow and ice */
      colors[8] = opaque|(255<<16)|(255<<8)|255;

      /* set the rest to pink */
      for (int i=9; i<16; i++)
	colors[i] = opaque|(255<<16)|(0<<8)|255;
	
    }	// ****************	end of method "pnnColors"	 ****************

  public static void main(String[] args)
    {
      int i;

      pnnColors c = new pnnColors();
      for(i=0;i<16;i++)
	System.out.println("Color " + i + " = " + c.colors[i] + "\n");
    }
	
}	// ****************	end of class "pnnColors"	****************			 
