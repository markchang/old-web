// pnnDialogs.java

import java.io.*;
import java.awt.*;
import java.awt.event.*;


/**
*	Contains various dialogs for the PNN application.	In general, the dialogs notify the
*	parent when they receive an important event - this class only handles such things as 
*	the "Ok" button on non-input windows, such as the info dialog, or 
*	"Cancel" for any dialog.	
*
*	It does not yet support the creation of more than one dialog in either a serial 
*	or concurrent way. The proper way to use this class is to create a new instance	
*	for each dialog needed, like this:
*
*	new pnnDialogs(this).InfoDialog("About Something", "Author: Dan", "NASA");
*
*	@param	screen			Dimension, conatinaing the pixel resolution of the machine's screen   
*  @param   answer         Boolean, contains results of query
*  @param   query_no       Button
*  @param   query_yes      Button
*  @param   helpreader_ok  Button
*  @param   info_ok        Button
*  @param   parent         Frame which represents the parent application
*  @version 0.3 May 8, 1998
*  @author Dan Greenspan, ASDP team, NASA Goddard Space Flight Center (GSFC)
*/


public class pnnDialogs  extends Dialog
                         implements ActionListener
{



   private Frame        parent;
   private Button       info_ok, helpreader_ok, query_yes, query_no;
   private boolean      answer;
   private Dimension    screen;
   


   /**
   *  Call the ancestor constructor, get screen dimensions, and set up a universal 
   *  parent for all dialogs.
   */
   public pnnDialogs(Frame p)
   {
      super(p);
      parent = p;
      screen = Toolkit.getDefaultToolkit().getScreenSize();    
      
      // look at dialog instructions to see how to handle this without killing parent
      //addWindowListener( new windowWatcher(this) );        
              
   }  // ****************  end of method "pnnDialogs"  **************** 
   
   
   
   /**
   *  makes a query dialog with the specified message.  The user selects "yes" or "no"
   *  and the method can then be queried for the response:
   *
   *  pnnDialogs qd = new pnnDialogs(this);
   *  boolean answer = qd.QueryDialog("The title", "The message");
   *  if ( answer == true)
   *     System.out.println("User said yes");
   *  else
   *     System.out.println("User said no");  
   *
   *  The dialog is placed in the middle of the application's workspace and is modal.
	*
	*	This version displays one line of text.
	*
	*	@param title	String, conatiains dialog title
	*	@param one		String, contains question
	*/
	public boolean QueryDialog(String title, String one)
	{	
		setLayout( new BorderLayout() );
			 
		Label label1 = new Label(one, Label.CENTER);
		add("North", label1);
		
		Panel buttons = new Panel();
		query_yes = new Button("yes");
		query_no = new Button("no");
		query_yes.addActionListener(this);
		query_no.addActionListener(this);
		buttons.add(query_yes);
		buttons.add(query_no);
		add("South", buttons);
		
		setTitle(title);
		setModal(true);
		setResizable(false);
		pack();

		centerInParent();
		show();									  
		
		return answer;
		
	}	// ****************	end of method "QueryDialog(S,S)"	 ****************		



	/**
	*	makes an info dialog with the specified message.  "Ok" does nothing but exit.
	*	The dialog is placed in the imddle of the application's workspace and is modal.
   *
   *  This version displays three lines of text.
   *
   *  @param title   String, contains dialog title
   *  @param one     String, contains first line of text
   *  @param two     String, contains second line of text
   *  @param three   String, contains third line of text
   */
   public void InfoDialog(String title, String one, String two, String three)
   {  
      setLayout( new GridLayout(4, 1) );
          
      Label label1 = new Label(one, Label.CENTER);
      add(label1);
      Label label2 = new Label(two, Label.CENTER);
      add(label2);
      Label label3 = new Label(three, Label.CENTER);
      add(label3);
      
      Panel buttons = new Panel();
      info_ok = new Button("Ok");
      info_ok.addActionListener(this);
      buttons.add(info_ok);
      add(buttons);
      
      setTitle(title);
      setModal(true);
      setResizable(false);
      pack();
      
      centerInParent();
      show();
                                
   }  // ****************  end of method "InfoDialog(S,S,S,S)"  ****************
   
   
   
   /**
   *  makes an info dialog with the specified message.  "Ok" does nothing but exit.
   *  The dialog is placed in the imddle of the application's workspace and is modal.
	*
	*	This version displays two lines of text.
	*
	*	@param title	String, contains dialog title
	*	@param one		String, contains first line of text
	*	@param two		String, contains second line of text	
	*/
	public void InfoDialog(String title, String one, String two)
	{	
		setLayout( new GridLayout(3, 1) );
			 
		Label label1 = new Label(one, Label.CENTER);
		add(label1);
		Label label2 = new Label(two, Label.CENTER);
		add(label2);
		
		Panel buttons = new Panel();
		info_ok = new Button("Ok");
		info_ok.addActionListener(this);
		buttons.add(info_ok);
		add(buttons);
		
		setTitle(title);
		setModal(true);
		setResizable(false);
		pack();
		
		centerInParent();
		show();
		
	}	// ****************	end of method "InfoDialog(S,S,S)"  ****************	
	
	
	
	/**
	*	makes an info dialog with the specified message.  "Ok" does nothing but exit.
	*	The dialog is placed in the middle of the application's workspace.
	*
	*	This version displays one line of text.
	*
	*	@param title	String, contains dialog title
	*	@param one		String, contains text	 
	*/
	public void InfoDialog(String title, String one)
	{	
		setLayout( new BorderLayout() );
			 
		Label label1 = new Label(one, Label.CENTER);
		add("North", label1);
		
		Panel buttons = new Panel();
		info_ok = new Button("Ok");
		info_ok.addActionListener(this);
		buttons.add(info_ok);
		add("South", buttons);
		
		setTitle(title);
		setModal(true);
		setResizable(false);
		pack();

		centerInParent();
		show();
		
	}	// ****************	end of method "InfoDialog(S,S)"	****************		 
	
	
	
	/**
	*	makes a help reader.	 "Ok" does nothing but exit.	The text shown is
	*	read directly from the file named by the parameter String.	Later, this will have
	*	a search function, possibly even an HTML interpreter.
	*
	*	@param	help_filename	String name of text file to be displayed.
	*/
	public void HelpReader( String help_filename )
	{	
		setLayout( new BorderLayout() );
			 
		TextArea text = new TextArea("", 25, 80, 1);
		text.setEditable(false);  
		text.setBackground(Color.black);
		text.setForeground(Color.cyan);
		add("North", text);
		
		Panel buttons = new Panel();
		helpreader_ok = new Button("Ok");
		helpreader_ok.addActionListener(this);
		buttons.add(helpreader_ok);
		add("South", buttons);
		
		setTitle("PNN Information");
		setModal(false);
		setResizable(false);
		pack();
		
		// load the instruction text
		try
		{
			FileReader fr = new FileReader(help_filename);
			BufferedReader in = new BufferedReader( fr );
			String line;
			while( (line = in.readLine()) != null)
				text.append(line + "\n");
			in.close();
			fr.close();
		}
		catch ( IOException ioe)
		{
			text.append( ioe.toString() );
		}

		// center in screen
		centerInScreen();
		show();
		
	}	// ****************	end of method "HelpReader"	 ****************
	
	
	
	/**
	*	utility method that positions a dialog over the center of the parent.
	*		  
	*/
	private void centerInParent()
	{
		Rectangle parentSpace = new Rectangle( parent.getBounds() );
		Rectangle r = new Rectangle( getBounds() ); 
		int xloc = (int)(0.5 + parentSpace.x + ((parentSpace.width - r.width))/2);
		int yloc = (int)(0.5 + parentSpace.y + ((parentSpace.height - r.height))/2);	 
		setLocation(xloc, yloc);
		
	}	// ****************	end of method "centerInParent"  ****************
	
	
	
	/**
	*	utility method that positions a dialog over the center of the screen.
	*		  
	*/
	private void centerInScreen()
	{
		Rectangle r = new Rectangle( getBounds() ); 
		int xloc = (int)(0.5 + ((screen.width - r.width))/2);
		int yloc = (int)(0.5 + ((screen.height - r.height))/2);	 
		setLocation(xloc, yloc);
		
	}	// ****************	end of method "centerInScreen"  ****************		
	
	
	
	/**
	*	The event processing loop.
	*/
	public void actionPerformed(ActionEvent ae)
	{
		Object source = ae.getSource();	// find out what generated the event
		
		if ( source == helpreader_ok )
			this.dispose();
			
		if ( source == info_ok )
			this.dispose();
			
		if ( source == query_yes )
		{
			answer = true;
			this.dispose();
		}
			
		if ( source == query_no )
		{
			answer = false;
			this.dispose();
		} 
							
	}	// ****************	end of method "actionPerformed"	****************	 


	
	public static void main(String args[])
	{
		Frame f = new Frame();
		f.setSize(500, 500);
		f.show();
		pnnDialogs pd = new pnnDialogs(f);
		
		//boolean answer = pd.QueryDialog("Soap", "Do you know the meaning of oomphalloskepsis?"); 
		//System.out.println(answer);
		
		//pd.InfoDialog("title", "frog!");
		
		pd.HelpReader("instructions.txt");
		
	}	// ****************	end of method "main"	 ****************
	
	
	
}	// ****************	end of method "pnnDialogs"	 ****************		  
