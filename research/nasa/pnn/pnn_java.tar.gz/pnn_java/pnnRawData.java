// RawData.java

import java.io.*;	  
import java.awt.*;			  
import java.awt.image.*;

/**
* A data container for the Pnn algorithm's raw data.  Beta and Hacky.  
* I don't want it to be a Component, but so far it is the only way I
*	know of to get createimage and memoryimagesource to work.
*
*	@version 0.3 May 7, 1998
*	@author Dan Greenspan, ASDP team, NASA Goddard Space Flight Center (GSFC)
*/

public class pnnRawData 
{
  public String	image_filename = "", training_filename = "";
  public int rows,cols, bands, patterns, num_classes, bytes_per_entry;
  public int[] pixels, weights;
  public ClassType[] Class;							  
				

  /**
    *	data container used by pnnRawData
    */
  public class ClassType
  {
    public int ClassNumber, patterns, sigma;
							
  }	// ****************	end of class "ClassType"	****************							 
							
							
							
  /**
    *	Loads the raw data (training/image) files, initializes data structures.	 
    *	The data files are loaded in 
    *	seperate try/catch structures so that if there is a failure, the user
    *	can identify which file caused the problem.	The input data is byte-swapped
    *	in this version because we are reading a file created in C/C++ on an intel box.
    *	Things I don't like about the way i did this: there's no way to
    *	check that the files belong together(checking that the number of band is the same) 
    *	and it only works on NT - running this on UNIX will cause errors
    *	(because of the file byte order).
    *		  
    */
  public pnnRawData(String iname)
    {
      int	imagefile_bands, i;
      image_filename = iname;	 
		
      // construct name and open training file
      // The training file name is based on the image file name, so it's easy to get 
      // it without the user specifically entering it.
      training_filename = new String( getTrainingName(image_filename) );

      System.out.println("Reading raw data...\n");
      
      try
	{                                                                                    
	  DataInputStream tfile = new DataInputStream( new FileInputStream(training_filename) );
           
	  // get first four bytes (header)
	  bands = bitSwitch( tfile.readInt() );    
	  patterns = bitSwitch( tfile.readInt() ); 
	  num_classes = bitSwitch( tfile.readInt() );

	  System.out.println("Bands " + bands + " patterns " + patterns + " num_classes " + num_classes +"\n");

	  if ( tfile.readInt() != 0)  // the null end of header marker
	    {
	      System.err.println("\n** File error! **");
	      System.err.println("The fourth byte of the training file is not NULL.\n");
	    }
         
	  weights = new int[bands*patterns];
	  Class = new ClassType[num_classes];
      
	  // read in training data 
	  // later, change this to buffer/pick method as with image data
	  for(i=0; i<(bands*patterns); i++)
            weights[i] = bitSwitch( tfile.readInt() );
            
	  // read in the classes
	  for(i=0; i<num_classes; i++)
	    {
	      Class[i] = new ClassType();
	      Class[i].ClassNumber = bitSwitch( tfile.readInt() );
	      Class[i].patterns= bitSwitch( tfile.readInt() );
	      Class[i].sigma= bitSwitch( tfile.readInt() );      
	    }
         
	  // close the stream(file)
	  tfile.close();   
	}
      catch (IOException ioe)
	{
	  System.err.println("\n** Training file error! **\n" + ioe);
	  // add more detailed diagnostic message here
	  return;
	}
       
      
      // open image file
      try
	{
	  DataInputStream ifile = new DataInputStream( new FileInputStream(image_filename) );
         
	  // get first four bytes (header)
	  rows = bitSwitch( ifile.readInt() );
	  cols = bitSwitch( ifile.readInt() ); 
	  imagefile_bands = bitSwitch( ifile.readInt() ); 
	  bytes_per_entry = bitSwitch( ifile.readInt() ); 
         
	  pixels = new int[rows*cols*bands];   // large enough for all bands
	  byte[] buffer = new byte[pixels.length*bytes_per_entry]; 
	  // large enough to hold all 32-bit 
	  // pixels as 8-bit bytes
         
	  // read the whole file into the byte array for speed
	  ifile.readFully(buffer);
                
	  // Luckily, none of the values in the image has more than 8 bits,
	  // so we can read the first byte of each INT32 and
	  // use it as the pixel value, rather than swapping nibbles as we did
	  // for the larger header values.
	  for(i=0; i<pixels.length; i++)
            pixels[i] = (int)buffer[i*bytes_per_entry];
         
	  // close the stream(file)
	  ifile.close(); 
            
	}
      catch (IOException ioe)
	{
	  System.err.println("\n** Image file error! **\n" + ioe);
	  // add more detailed diagnostic message here
	  return;
	}
      
                                  
    }  // ****************  end of method "RawData"   ****************     


   
  /**
    *  A utility method that returns the qualified training file name. 
    *  
    */
  private String getTrainingName(String filename)
    {
      int dot;
      
      dot = filename.lastIndexOf("."); 
         
      return ( filename.substring(0, dot) + ".trn" );
   
    }  // **************** end of method "getTrainingName" ****************
   
   
   
  /**
    *  A utility method to reverse the bytes in each INT32 read in from disk, since they 
    *  were written with C/C++ and are little-endian (JAVA uses big-endian). Yes, I know
    *  it's a kludge, and there are other ways of doing this (numerically, 
    *	using / and * by powers of two, among others). There's got to be a more elegant method 
    *  of doing this - it's going to slow data reading down for large files!
    */
  private int bitSwitch(int number)
    {
      int temp, swapped;
		
      // you have to use shift right without sign extension ( >>> ) in case it's "negative"
      swapped = (number >>> 24);   
      swapped = (number << 24) | (swapped);
      temp = (number >>> 8);
      temp = (temp << 24);
      swapped = (temp >>> 8)|(swapped);
      temp = (number << 8);
      temp = (temp >>> 24);
      swapped = (temp << 8) | (swapped);
      
      return swapped;
                       
    }  // **************** end of method "bitSwitch" **************** 



  /**
    *  This method contains displays some info about a file. 
    *  Run "java pnnRawData <image file name>" to see info on the file's contents.
    *
    *@param	args[0]	the name of the image file 
    */	 
  public static void main(String[] args)
    {
      int i;
		
      if( args.length == 0)
	{
	  System.err.println("\n** Usage: java pnnRawData <image filename> ** \n");
	  System.exit(1);
	}
		
      pnnRawData thing = new pnnRawData(args[0]);
		
      System.out.println("\nTraining file: " + thing.training_filename + "\n" + 
			 "rows x cols x bands = " + thing.rows + " x " + thing.cols + " x " + thing.bands + "\n" + 
			 "\nnumber of classes: " + thing.num_classes
			 );
		
      for(i=0; i<thing.num_classes; i++) 
	{
	  System.out.println("Class: " + thing.Class[i].ClassNumber + 
			     " patterns: " + thing.Class[i].patterns + 
			     " sigma: " + thing.Class[i].sigma
			     );	 
	}
		
      System.out.println("\nnumber of weights: " + thing.bands*thing.patterns + "\n" +
			 "First six weights:");
      for(i=0; i<6; i++)
	{
	  System.out.println("0x" + Integer.toHexString(thing.weights[i]));
	}
		
		
      System.out.println("\nImage file: " + thing.image_filename + 
			 "\nNumber of pixels in band one: " + thing.rows*thing.cols + "\n" +
			 "\nFirst six pixels:"
			 );
		
      for(i=0; i<6; i++)
	System.out.println("0x" + Integer.toHexString(thing.pixels[i]));
    }

	
	
}	// ****************	end of class "RawData"	 ****************



