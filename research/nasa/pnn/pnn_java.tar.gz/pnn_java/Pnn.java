// Pnn.java


import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;


/**
  *	A functional PNN software-only algorithm, 
  *	with dialogs added, but it needs some finishing touches.
  *
  *	@version 0.5 May 8, 1998
  *	@author Dan Greenspan, ASDP team, NASA Goddard Space Flight Center (GSFC)
  */


public class Pnn extends Frame implements ActionListener, Runnable			 
{
  private Image image = null;
  private int[] pixels;// visible image pixels 
  private pnnRawData raw_data; 
  private String image_filename, lastdir = "";
  private MenuItem[] file_choice = new MenuItem[5], classify_choice = new MenuItem[3], imagemenu_choice = new MenuItem[1];
  private boolean tmode = false;
  private String usermessage;  
  private MemoryImageSource source;
  private pnnColors colors = new pnnColors();                                        
  
  /**  
    *	Constructor class that takes no arguments.
    *	The GUI portion of the application is initialized in this method.
    *
    *	@param title	the title of the application window
    */	 
  public Pnn()
    {
      new Pnn("Pnn Demonstration");
      
    }	// ****************	end of constructor method "Pnn()"	****************
  
  
  
  /**  
    *	Constructor class that takes a title string as its argument.
    *	The GUI portion of the application is initialized in this method.
    *
    *	@param title	the title of the application window
    */
  public Pnn (String title)			  
    {	 
      int i;
      Menu	file, classify, imagemenu, help;
      MenuBar menubar;
      
      // Set up a listener to take care of top-window-level events
      // such as canceling (a click on the "x" box in the upper right corner).
      // See "windowWatcher" the the documentation of this project for details.
      addWindowListener( new windowWatcher(this) );
      
      setTitle(title);
      setBackground(Color.gray); 
      
      // create GUI here
      file = new Menu("File");
      file.add( newMenuItem("Load raw data") );
      file.add( newMenuItem("Open classified data") );
      file.add( file_choice[2] = new MenuItem("Save") );
      file.add( file_choice[3] = new MenuItem("Save as") );
      file.addSeparator();
      file.add( newMenuItem("Exit") );
      // disable these since they can't be used at this point
      for(i=2; i<4; i++)
		  {
			 file_choice[i].addActionListener(this);
			 file_choice[i].setEnabled(false);
		  }      
      
      classify = new Menu("Classify");
      classify.add( classify_choice[0] = new MenuItem("Local software") );
      classify.add( classify_choice[1] = new MenuItem("Remote single-module hardware") );
      classify.add( classify_choice[2] = new MenuItem("Remote dual-module hardware")) ;
      // disable these since they can't be used at this point
      for(i=0; i<3; i++)
		  {
			 classify_choice[i].addActionListener(this);
			 classify_choice[i].setEnabled(false);
		  } 
      
      imagemenu = new Menu("Image");
      imagemenu.add( imagemenu_choice[0] = new MenuItem("Invert") );
      imagemenu_choice[0].addActionListener(this);
      imagemenu_choice[0].setEnabled(false);
      
      help = new Menu("Help");
      help.add( newMenuItem("Instructions") );
      help.add( newMenuItem("About") );
      
      menubar = new MenuBar();
      menubar.add(file);
      menubar.add(classify);
      menubar.add(imagemenu);
      menubar.setHelpMenu(help); // How do I get it to appear on the right side?
      setMenuBar(menubar);
      
      setSize(400, 400);
      
      // make us visible to the world
      setVisible(true);								 

    }	// ****************	end of constructor method "Pnn(String)"	****************
  
  
  
  /**
    *	The event processing loop.
    */
  public void actionPerformed(ActionEvent ae)
    {
      String source = ae.getActionCommand();	 // find out what generated the event
      
      if ( source.equals("Exit") ) 
		  file_exit();	
      
      if ( source.equals("Load raw data") )
		  file_loadraw();
		
      if ( source.equals("Open classified data") )
		  file_open();
		
      if ( source.equals("Save") )
		  file_save();
		
      if ( source.equals("Save as") )
		  file_save_as();
		
      if ( source.equals("Instructions") )
		  help_instruct();
		
      if ( source.equals("About") )
		  help_about();
		
      if ( source.equals("Local software") )				 
		  new Thread(this).start();
      //classify_local();
			
      if ( source.equals("Remote single-module hardware") )
		  classify_Remote_1_Mod();
			
      if ( source.equals("Remote dual-module hardware") )
		  classify_Remote_2_Mod();
		
      if ( source.equals("Invert") )
		  imagemenu_invert();

    }	// ****************	end of method "actionPerformed"	****************
	
	
	
  /**
    *	The callback for New on the file menu. This is how you start a new
    *	classification.
    */
  private void file_loadraw()
    {
      // We need to flush the image so that updateImage will be called, even if
      // this image has been previously loaded (the system caches it).	But if 
      // cancel is pressed, we will need to get it back.
      Image lastimage = image;
      if (image != null)
		  image.flush();
		
      FileDialog rd = new FileDialog(this, "Raw image load", FileDialog.LOAD);
      rd.setFile("*.dat");
      rd.setDirectory(lastdir);
      rd.show();
      
      // put things back the way they were if user canceled		  
      if ( rd.getFile() == null ) // you can't use .equals because the string might not exist
		  {
			 image = lastimage;
			 return;
		  }
      
      lastdir = rd.getDirectory();
      // the fully qualified names of image and training files
      image_filename = lastdir + rd.getFile();       
      
      // get the raw data
      getRawData(image_filename);
      repaint();   
      
      for(int i=2; i<4; i++)      
		  file_choice[i].setEnabled(true);
      
    }  // ****************  end of method "file_loadraw"  ****************
  
   
   
  /**
    *  The callback for Open on the file menu. It would be nice to add (16 bit and above)
    *  BMP and GIF/JPEG support for loads and saves.  
    */
  private void file_open()
    {
      // We need to flush the image so that updateImage will be called, even if
      // this image has been previously loaded (the system caches it).  But if 
      // cancel is pressed, we will need to get it back.
      Image lastimage = image;
      if (image != null)
		  image.flush();
         
      FileDialog pd = new FileDialog(this, "Processed image load", FileDialog.LOAD);
      pd.setFile("*.gif");
      pd.setDirectory(lastdir);
      pd.show();

      // put things back the way they were if user canceled      
      if ( pd.getFile() == null ) // you can't use .equals because the string might not exist
		  {
			 image = lastimage;
			 return;
		  }

      // make sure inappropriate menu choices are disabled
      for(int i=0; i<1; i++)
		  classify_choice[i].setEnabled(false);		 
      imagemenu_choice[0].setEnabled(false);
		
      image_filename = pd.getDirectory() + pd.getFile(); // the fully qualified name
      lastdir = pd.getDirectory();
			
      // Remember, this returns instantly, although the image hasn't been loaded yet.
      image  = Toolkit.getDefaultToolkit().getImage(image_filename); 
      repaint();
           
      for(int i=2; i<4; i++)      
		  file_choice[i].setEnabled(true);      

    }  // ****************  end of method "file_open"  ****************
   
   
   
  /**
    *  The callback for Exit on the file menu.
    */
  private void file_exit()
    {
      boolean answer = new pnnDialogs(this).QueryDialog("Exit", "Are you sure you want to exit?");
      if ( answer == true )
		  System.exit(0);
      
      return;
      
    }  // ****************  end of method "file_exit"  ****************



  /**
    *  The callback for Save on the file menu.
    */
  private void file_save() 
    {
      try {
        DataOutputStream dos = new DataOutputStream(
																	 new FileOutputStream("output.j.raw"));

		  System.out.println("Writing " + pixels.length+" bytes to output.j.raw\n");
		  for(int i=0;i<pixels.length;i++)
			 dos.writeInt(pixels[i]);
	
		  dos.close();
	
		  System.out.println("Wrote file output.raw\n");
      }
      catch(IOException e){
      }

      
    }  // ****************  end of method "file_save"  ****************   



  /**
    *  The callback for "Save as" on the file menu.
    */
  private void file_save_as()
    {
      FileDialog pd = new FileDialog(this, "Save processed image", FileDialog.SAVE);
      pd.setFile("*.gif");
      pd.setDirectory(lastdir);
      pd.show();

      image_filename = pd.getDirectory() + pd.getFile(); // the fully qualified name
      
      if ( pd.getFile().equals(null) )
		  return;
         
      lastdir = pd.getDirectory();
         
      //Toolkit.getDefaultToolkit().getImage(image_filename);        
      
    }  // ****************  end of method "file_save_as"  ****************   


   
  /**
    *  The callback for Info on the help menu.
    */
  private void help_instruct()
    {
      new pnnDialogs(this).HelpReader("instructions.txt");
   
    }  // ****************  end of method "help_instruct"  ****************
   
   
   
  /**
    *  The callback for About on the help menu.
    */
  private void help_about()  
    {
      new pnnDialogs(this).InfoDialog(    "About PNN",
                                          "PNN demonstrator 1.0",
                                          "Adaptive Scientific Data Processing (ASDP) group",
                                          "NASA Goddard Space Flight Center"
														); 
         
    }  // ****************  end of method "help_about"  ****************
   
   
   
  /**
    *  This overrides the existing method, which this class inherits because
    *  all JAVA objects extend the imageObserver class. So, you don't need to put
    *	"implements ImageObserver" in your class declaration.
    *	<p>
    *	This method is only called when something has changed; if an image is not
    *	referenced by a drawImage or some other function, imageUpdate is not called.
    *	<p>
    *	This method:
    *	<ul><ul>
    *	<li>resizes the display when the image's size has been obtained
    *  <li>repaints at regular intervals until the image is fully loaded
    *  <li>has a primitive error handling routine 
    *  </ul></ul>
    */   
  public boolean imageUpdate(Image the_image, int flags, int x, int y, int width, int height )
    {
      if ( (flags & ERROR) != 0) 
		  {
			 System.err.println("Image file error!\n");   
		  }
      
      // when dimensions are available, resize the application to fit the image                                                                        
      if ( ((flags & WIDTH) != 0) &&  ((flags & HEIGHT) != 0) ) 
		  {
			 setSize(width, height);    // When this is executed, width and height are final.
			 Insets ins = getInsets();  // declare ins here instead of at top of method
			 // so that it only gets declared when needed.
                         
			 setSize( (width + ins.left + ins.right), 
						 (height + ins.top + ins.bottom) 
						 );
		  }

      
      // Repaint now if we are done, otherwise repaint every 300 mS
      boolean done = ( (flags & ALLBITS) != 0 );   // are we there yet?                 
      if (done)                  
		  repaint(0);
      else    
		  repaint(300);                
                   
      return !done;  //If done, return false, which indicates that no further 
      // calls to this function are necessary. Else return true; 
      // if true is returned, this method will be called whenever 
      // new info about the image arrives.
                     
    }  // ****************  end of method "imageUpdate" ****************
   


  /**
    *  Redraws the image within our window when needed; called by the system.  
    *  Overrides the system's default paint method. 
    */
  public void paint(Graphics g)
    {	
      if (tmode)
		  {
			 Font f = new Font("Helvetica", Font.BOLD, 24);// inefficient; create the font once!
			 g.setFont(f);
			 g.drawString(usermessage, 10, 100);
			 tmode = false;								  
		  }
      else
		  {	
			 Insets ins = this.getInsets();
			
			 if (image != null)				 
				g.drawImage(image, ins.left, ins.top, this);
		  }
		
    }	// **************** end of method "paint" ****************
	
	
	
  /**
    *	an update method that doesn't erase the screen. This eliminates flicker.
    */
  public void update(Graphics g)
    {
      paint(g);
      
    }  // **************** end of method "update" ****************
   
   
   
  /**
    *  A utility function that creates a new menu item and sets up an actionlistener. 
    *  This should only be used when you don't need to control the MenuItem.
    */
  private MenuItem newMenuItem(String name)
    {
      MenuItem item = new MenuItem(name);
      item.addActionListener(this);
		
      return item;
		
    }	// **************** end of method "newMenuItem" ****************
	
	
	
  /**
    *	A utility function that sets the wait cursor and puts a message 
    *	on the screen while loading the raw data. I have to figure out how 
    *	to get the cursors to update without the mouse moving.
    */
  private void getRawData(String image_filename)
    {										
      ((Component)this).setCursor( new Cursor(Cursor.WAIT_CURSOR) ); 
      userMessage("Loading data...");
		
      // I should have some kind of error checking around this!
      raw_data = new pnnRawData(image_filename);
				
      // get pixel data
      pixels = new int[raw_data.rows*raw_data.cols];
		
      //make Raw Image
      image = makeImage();		 
		
      ((Component)this).setCursor( new Cursor(Cursor.DEFAULT_CURSOR) ); 
      repaint();	// to get rid of the message
		
      // make appropriate menu coices accessible
      for(int i=0; i<1; i++)
		  classify_choice[i].setEnabled(true);
      imagemenu_choice[0].setEnabled(true);		 
		
    }	// **************** end of method "getRawData" ****************
	
	
	
  /**
    *	A utility function that put a message on the application's window.
    */
  private void userMessage(String message)
    {
      tmode = true;
      usermessage = message;
      repaint();
		
    }	// **************** end of method "userMessage" ****************



  /**
    *	creates a black and white image from the raw data.	 Animation is used to allow 
    *	visual updating of the image as processing progresses. The resulting image
    *	is inverted to give the picture a natural appearance.	 Each pixel is constructed by
    *	summing all four bands for that pixel.
    */
  public Image makeImage() 
    {	
      int p=0, i, b;
		
      for(i=0; i<pixels.length; i++)
		  {	 
			 // create a pixel that is the sum of the values from all bands of this pixel	
			 for(b=0; b<raw_data.bands; b++)
				pixels[i] += raw_data.pixels[p++];
				 
			 pixels[i] = (0xff<<24)|(pixels[i]<<16)|(pixels[i]<<8)|(pixels[i]); // construct B+W pixel
			 pixels[i] ^= 0x00ffffff;	// invert for natural appearance
		  }
		
      image = createImage( source = 
									new MemoryImageSource(raw_data.cols, raw_data.rows, pixels, 0, raw_data.cols) );
      source.setAnimated(true);
		
      return image;
		
    }	// ****************	end of method "makeImage"	 ****************
	
	
	
  /**
    *	inverts raw data by XORing all bits except alpha bits of each pixel. 
    *	I should rewrite this to do the whole image, not just one row at a time.
    */
  private void imagemenu_invert()
    {
      int start;			 
					
      for (int y = 0; y<raw_data.rows; y++)
		  {
			 start = (y*raw_data.cols);
			 for(int x=start; x<(start+raw_data.cols); x++)
				pixels[x] ^= 0x00ffffff;					 
			 source.newPixels(0, y, raw_data.cols, 1);
					
		  }													 
				
    }	// ****************	end of method "imagemenu_invert"	  ****************
  
	
 
  /**
    *	Classifies band 1 using local floating-point algorithm and overwrites the 
    *	raw image with classified data. 
    */
  public void run()
    //private void classify_local()	 
    {
      System.out.println("entered classify_local");
      ((Component)this).setCursor( new Cursor(Cursor.WAIT_CURSOR) );
			
      double tmp, 
		  tmpfl[] = new double[raw_data.num_classes],
		  sigma_x, 
		  maxval_x, 
		  curval_x, 
		  term_x, 
		  exp_m_x, 
		  class_sum_x;
      int Class, 
		  weight, 
		  diff, 
		  pix=0, 
		  start;
      long psum;

      // precompute some sigma-based values
      tmp = Math.pow(2.0*(22.0/7.0) , (raw_data.bands/2.0) );
      for (Class = 0; Class < raw_data.num_classes; Class++)
		  tmpfl[Class] = tmp * Math.pow(raw_data.Class[Class].sigma, raw_data.bands);
      sigma_x= Math.pow(raw_data.Class[--Class].sigma, 2); 

      // classify entire image, row by row
      for (int y = 0; y<raw_data.rows; y++)			 
		  {
			 // classify a row
			 start = (y*raw_data.cols);
			 System.out.println("Row :"+y);
			 for(int x=start; x<(start+raw_data.cols); x++)
				{	
				  maxval_x = -1;
				  weight=0;
				
				  for(Class=0; Class<raw_data.num_classes; Class++)
					 {
						class_sum_x = 0;
					
						for(int pattern=0; pattern<raw_data.Class[Class].patterns; pattern++)
						  {
							 psum = 0;
						
							 for(int bands=0; bands<raw_data.bands; bands++)
								{
								  diff = raw_data.pixels[pix+bands] - raw_data.weights[weight++];
								  psum += diff * diff;
								} // end of bands loop
						
							 term_x = ((double)psum)/(2.0*sigma_x);
							 exp_m_x = Math.exp(-term_x);
							 class_sum_x += exp_m_x;	  
						
						  } // end of pattern loop
					
						if (raw_data.Class[Class].patterns == 0)
						  {
							 curval_x = -1;
						  } 
						else 
						  {
							 curval_x = class_sum_x / (tmpfl[Class] * raw_data.Class[Class].patterns);
						  }
					
						// assign color to pixel based on the largest class score.
						if (maxval_x < curval_x)
						  {
							 maxval_x = curval_x;
							 pixels[x] = colors.colors[raw_data.Class[Class].ClassNumber];
						  } 
					
					 } // end of Class loop										 
				
				  pix += raw_data.bands; // increment the raw data pixel "pointer"
				
				} // end of x (row) loop
			
			 // a row is finished; send the newly classified row to the screen
			 source.newPixels(0, y, raw_data.cols, 1);
					
		  } // end of y (entire image) block
		 
      ((Component)this).setCursor( new Cursor(Cursor.DEFAULT_CURSOR) );
														  
      System.out.println("exited classify_local");	  
		
    }	// ****************	end of method "classify_local"	****************
	
	
	
  /**
    *	Classifies band 1 using remote single-module FPGA algorithm and overwrites the 
    *	raw image with classified data.	
    */
  private void classify_Remote_1_Mod()
    {
		
	
    }	// ****************	end of method "classify_Remote_1_Mod"	 ****************
	
	
	
  /**
    *	Classifies band 1 using remote dual-module FPGA algorithm and overwrites the 
    *	raw image with classified data.	
    */
  private void classify_Remote_2_Mod()
    {
	
    }	// ****************	end of method "classify_Remote_2_Mod"	 ****************

  
  
  /**
    *	Instantiates a new Pnn object.
    */
  public static void main(String argv[])
    {	
      new Pnn();
		 
    }	// ****************	end of method "main" ****************



}	// ****************	end of class "Pnn"	****************


  
