// windowWatcher.java


import java.awt.*;
import java.awt.event.*;


/**
*
* This is a "utility" class that takes care of top-window-level events
* such as cancel, minimize, maximize, resize etc.
* by implementing the windowAdapter class.  To use it, merely leave a copy
* of the windowWatcher.class file in your program's directory.
* 
* For details, see   
*
* <a href="http://java.sun.com/products/jdk/1.1/docs/api/java.awt.event.WindowAdapter.html">
* this URL</a> on sunsoft's home page.
* @version 0.1 April 27, 1998
* @author Dan Greenspan, ASDP team, NASA Goddard Space Flight Center (GSFC)
* @param parent the user class, which has to be of type Frame
*/


public class windowWatcher extends WindowAdapter
	// ovverride any windowAdapter method in here.
	{
	
	private Frame parent; 
		
		
	public windowWatcher(Frame o) 
	{
		parent = o;
	}
	
		
	/**	Code in this method is executed when the destroy box in the 
	*		upper right corner or the "close"
	*		option from the JAVA menu has been picked.
	*/
	public void windowClosing(WindowEvent we) 
	{
		boolean answer = new pnnDialogs(parent).QueryDialog("Quit", 
			"Exit PNN demonstration?");
		if ( answer == true )
			parent.dispose();	 // uninstantiate the window
		
		return;	 
	}
	
		
	/**	Code in this method is executed after the window has been closed
	*		(it's gone from the screen by this time).
	*/
	public void windowClosed(WindowEvent we)
	{	
		// we could have put this in windowClosing
		System.exit(0);	// end execution
	}
	
		
}	// end of class "windowWatcher"
