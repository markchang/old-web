DJ Mixr
PDF of powerpoint can also be found at: http://students.olin.edu/2012/rkim/MobDevMidTerm.pdf

Elevator Pitch
DJMixr, Droid Jam Mixer, is a revolutionary android application that lets people collectively play music.  It is Pandora, itunes Genius, a jukebox, and the party guests combined into one application that generates smart playlists.  With lots of ways to develop the idea so that this application applies to a larger scope, this product a great investment. 

Our Team
(in alphabetical order by first name)
*Hyeontaek Oh
*Miguel Bejar
*Poorva Singal
*Rhan Kim  - www.RhanKim.com

