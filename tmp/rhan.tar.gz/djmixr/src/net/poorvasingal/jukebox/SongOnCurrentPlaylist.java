package net.poorvasingal.jukebox;

public class SongOnCurrentPlaylist {
	
	private String title = "";
	private boolean thumbsUp = false;
	private boolean thumbsDown = false;
	
	public SongOnCurrentPlaylist(String title){
		this.title = title;
	}
	
	public String toString(){
		return getTitle(); 
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isThumbsUp() {
		return thumbsUp;
	}

	public void setThumbsUp(boolean thumbsUp) {
		this.thumbsUp = thumbsUp;
		if (this.thumbsUp) this.thumbsDown = false; 
	}

	public boolean isThumbsDown() {
		return thumbsDown;
	}

	public void setThumbsDown(boolean thumbsDown) {
		this.thumbsDown = thumbsDown;
		if (this.thumbsDown) this.thumbsUp = false;
	}

}
