package net.poorvasingal.jukebox;


import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CheckIn extends Activity {
    /** Called when the activity is first created. */
    static final int PROGRESS_DIALOG = 1;
	private String locSelected = "";
    ProgressThread progressThread;
    ProgressDialog progressDialog;
    final Activity activity = this;
    final String[] LOCATIONS = new String[] {"Miguel's Party", "Starbucks"};
    ListView locationList;
	
    //private EditText loc= null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_in);
        showDialog(PROGRESS_DIALOG);
        locationList = (ListView)findViewById(R.id.ci_listView);
        
        //loc = (EditText)findViewById(R.id.EditText01);
        
       
        
//        locationList.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, LOCATIONS));        
//        AdapterView.OnItemClickListener onLocationListClick=new
//        AdapterView.OnItemClickListener() {
//        	public void onItemClick(AdapterView<?> parent,
//        			View view, int position,
//        			long id) {
//        		locSelected=LOCATIONS[position];
//        		//oc.setText(locSelected);	  
//        		
//				Intent i =  new Intent(CheckIn.this, GuestPlaylist.class);
//				startActivity(i);
//    			
//        }
//        };
//
//      
//        locationList.setOnItemClickListener(onLocationListClick);
        

        AdapterView.OnItemClickListener onLocationListClick=new
        AdapterView.OnItemClickListener() {
        	public void onItemClick(AdapterView<?> parent,
        			View view, int position,
        			long id) {
        		locSelected=LOCATIONS[position];
        		//oc.setText(locSelected);	  
        		
				Intent i =  new Intent(CheckIn.this, GuestPlaylist.class);
				startActivity(i);
    			
        }
        };

      
        locationList.setOnItemClickListener(onLocationListClick);
        locationList.setAdapter(new ArrayAdapter<String>(CheckIn.this,android.R.layout.simple_list_item_1, LOCATIONS));        

        locationList.setAdapter(new ArrayAdapter<String>(CheckIn.this,android.R.layout.simple_list_item_1, LOCATIONS));        

        locationList.setVisibility(ListView.INVISIBLE);
        

        
    }
    
    protected Dialog onCreateDialog(int id) {
        switch(id) {
        case PROGRESS_DIALOG:
            progressDialog = new ProgressDialog(this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setMessage("Finding nearby host locations...");
            progressThread = new ProgressThread(handler);
            progressThread.start();

           
            return progressDialog;
        default:
            return null;
        }
    }
    // Define the Handler that receives messages from the thread and update the progress
    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            int total = msg.getData().getInt("total");
            progressDialog.setProgress(total);
            if (total >= 100){
                dismissDialog(PROGRESS_DIALOG);
                locationList.setVisibility(ListView.VISIBLE);
                progressThread.setState(ProgressThread.STATE_DONE);
            }
        }
    };
	

    /** Nested class that performs progress calculations (counting) */
    private class ProgressThread extends Thread {
        Handler mHandler;
        final static int STATE_DONE = 0;
        final static int STATE_RUNNING = 1;
        int mState;
        int total;
       
        ProgressThread(Handler h) {
            mHandler = h;
        }
       
        public void run() {
        	mState = STATE_RUNNING;   
            total = 0;
            while (mState == STATE_RUNNING) {
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    Log.e("ERROR", "Thread Interrupted");
                }
                Message msg = mHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putInt("total", total);
                msg.setData(b);
                mHandler.sendMessage(msg);
                total++;
            }
        }
        
        /* sets the current state for the thread,
         * used to stop the thread */
        public void setState(int state) {
            mState = state;
        }
    }

}