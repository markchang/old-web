package net.poorvasingal.jukebox;



import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class GuestPlaylist extends Activity {
    
	private final int SONG_PREFERENCES_REQUEST = 1;
	private SharedPreferences appPreferences;
	private SharedPreferences.Editor editor;
	private Bundle extras = null;
	private String SELECTED_CBS = "selected_cbs";
	private boolean[] selected = new boolean[] {false,false,false};
	private String filename = "checked.txt";
	
	
	List<SongOnCurrentPlaylist> currentSong = new ArrayList<SongOnCurrentPlaylist>(); 
	List<SongOnCurrentPlaylist> upcomingSongs = new ArrayList<SongOnCurrentPlaylist>(); 
	SongAdapter upcomingSongsAdapter = null;
	SongAdapter currentSongAdapter = null;
	
	/** Called when the activity is first created. */
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_playlist);
        
        currentSong.add(new SongOnCurrentPlaylist("Diplomat's Son")); 
        
        upcomingSongs.add(new SongOnCurrentPlaylist("Wonderwall"));
        upcomingSongs.add(new SongOnCurrentPlaylist("Beautiful Day"));
        upcomingSongs.add(new SongOnCurrentPlaylist("Jump then Fall"));
        
        appPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = appPreferences.edit();
        
        ListView playlistList = (ListView)findViewById(R.id.gp_playlistList);
        ListView currentList = (ListView)findViewById(R.id.gp_currentList);
        
        
        //final String[] SONGS = new String[] {"Wonderwall","Beautiful Day","Clocks"};
        
        
        //playlistList.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, SONGS));
        upcomingSongsAdapter = new SongAdapter(upcomingSongs); 
        playlistList.setAdapter(upcomingSongsAdapter);
        
        currentSongAdapter = new SongAdapter(currentSong); 
        currentList.setAdapter(currentSongAdapter);
        
        
        Button setSongPrefs = (Button)findViewById(R.id.gp_button01);
        
        setSongPrefs.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				//if (extras == null){
		        try {
		        	InputStream inputFile = openFileInput(filename);
		        	if (inputFile!=null) {
		        		
		        		BufferedReader reader = new BufferedReader(new InputStreamReader(inputFile)); 
		        		
		        		String in = reader.readLine(); 
		        		System.out.println(in);
		        		for (int j = 0; j < selected.length; j++){
		        			
		        			selected[j] = (in.substring(j, j+1).equals("0")? false:true);
		        			System.out.println(in.substring(j, j+1).equals("0")? "false":"true");
		        			//selected[j] = Boolean.valueOf(reader.readLine());
		        			//System.out.println(j+reader.readLine());
		        		}

		        	}
		        }
		        catch (java.io.FileNotFoundException e) {
		        	//Do nothing.. 
		        }
		        catch (Throwable t) {
		        }
				//}
				Intent i =  new Intent(GuestPlaylist.this, SongPreferences.class);
				
				
					extras = new Bundle();
					extras.putBooleanArray("checked", selected);
				
				
				i.putExtras(extras);
				startActivityForResult(i,SONG_PREFERENCES_REQUEST);
				
			}
		}); 
        
        
    }
    public void onResume(){
    	super.onResume(); 
//        boolean[] checked = appPreferences.get(arg0, arg1)("color",Color.WHITE);
//        editor.putInt("color", color);
//		editor.commit(); 
        
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
    	if (requestCode == SONG_PREFERENCES_REQUEST){
    		if (resultCode == RESULT_OK){
 
    			//extras = data.getExtras();
    			Bundle b = data.getExtras();
    			
    			boolean[] value = b.getBooleanArray(SELECTED_CBS);
    			extras.putBooleanArray("checked", value);
    			
    			
    		}
    	}
    }			
    
    class SongAdapter extends ArrayAdapter<SongOnCurrentPlaylist>{
    	List<SongOnCurrentPlaylist> songs;
    	SongAdapter(List<SongOnCurrentPlaylist> songs){
    		
    		super(GuestPlaylist.this, android.R.layout.simple_list_item_1,songs);
    		this.songs = songs; 
    	}
    	
    	public View getView(int position, View convertView,
    			ViewGroup parent) {
    		View row=convertView;
    		SongWrapper wrapper=null;

    		if (row==null) {
    			LayoutInflater inflater=getLayoutInflater();

    			row=inflater.inflate(R.layout.row, parent, false);
    			wrapper=new SongWrapper(row);
    			row.setTag(wrapper);
    		}
    		else {
    			wrapper=(SongWrapper)row.getTag();
    		}

    		wrapper.populateFrom(songs.get(position));

    		return(row);
    	}
    }
    
    class SongWrapper{
    	private TextView title = null;
    	private TextView artist = null;
    	private ImageView thumbsUp = null;
    	private ImageView thumbsDown = null; 
    	private View row = null;
    	private LinearLayout rowLayout = null;
    	
    	SongOnCurrentPlaylist song = null;
    	
    	
    	SongWrapper(View row){
    		this.row = row; 
    		

    	}
    	
    	 void populateFrom(SongOnCurrentPlaylist s) {
    		 this.song = s; 
    		 this.rowLayout = getRowLayout(); 
    		 getTitle().setText(s.getTitle());
    		 
     		thumbsUp = getThumbsUp(); 
    		thumbsUp.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					song.setThumbsUp(!song.isThumbsUp());
					setThumbsUp();
					setThumbsDown(); 
					
				}
			});
    		
     		thumbsDown = getThumbsDown(); 
    		thumbsDown.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					song.setThumbsDown(!song.isThumbsDown());
					setThumbsUp();
					setThumbsDown(); 
					
				}
			});
    	 }

     	LinearLayout getRowLayout(){
   		 if (rowLayout==null) {
   			 rowLayout=(LinearLayout)row.findViewById(R.id.row_main_layout);
   			 }
   			  
   		 return rowLayout; 
   			   		
   	}    	 
    	 
    	 
    	TextView getTitle(){
    		 if (title==null) {
    			 title=(TextView)row.findViewById(R.id.row_title);
    			 }
    			  
    			 return(title);    		
    	}
    	
    	TextView getArtist(){
   		 if (title==null) {
   			 title=(TextView)row.findViewById(R.id.row_artist);
   			 }
   			  
   			 return(title);    		
   	}    	
    
    	
    	
    	ImageView getThumbsUp(){
    		if (thumbsUp==null) {
    			thumbsUp=(ImageView)row.findViewById(R.id.row_image01);
    		}

    		return(thumbsUp);    		
    	}    	
    	
    	void setThumbsUp(){
    		//this.thumbsUp.setTextColor(song.isThumbsUp()?Color.GREEN:Color.BLACK);
    		thumbsUp.setImageResource(song.isThumbsUp()?R.drawable.tu_on:R.drawable.tu_off);
//       	
//    		int width = rowLayout.getWidth();
//    		int height = rowLayout.getHeight(); 
//    		
//    		LayoutParams lp = new LayoutParams(width, height);
//    		rowLayout.setLayoutParams(lp);
    	}
    	
    	ImageView getThumbsDown(){
    		if (thumbsDown==null) {
    			thumbsDown=(ImageView)row.findViewById(R.id.row_image02);
    		}

    		return(thumbsDown);    		
    	}      
    	
    	void setThumbsDown(){
    		
    		thumbsDown.setImageResource(song.isThumbsDown()?R.drawable.td_on:R.drawable.td_off);
    		
    	}

    }
}