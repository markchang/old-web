package net.poorvasingal.jukebox;


import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

public class SongPreferences extends Activity {
    /** Called when the activity is first created. */
	private String SELECTED_CBS = "selected_cbs";
	private CheckBox[] cbs;
	private String filename = "checked.txt";
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_song_pref);
        
        boolean[] selected = (savedInstanceState != null? savedInstanceState.getBooleanArray("checked"):null);
//        
//        
//        
        if(selected == null){
            
            Bundle extras = getIntent().getExtras();
            //check to see if "myKey" is in the bundle, if so then assign it's value
            // to mIntentString  if not, assign "nothing passed in" to mIntentString...
            selected = (extras != null ? extras.getBooleanArray("checked") : new boolean[]{false,false,false});
        }
        
        //boolean[] selected = new boolean[]{true, false, false};
        
        
        cbs = new CheckBox[3];
        cbs[0] = (CheckBox)findViewById(R.id.sp_checkbox01);
        cbs[1] = (CheckBox)findViewById(R.id.sp_checkbox02);
        cbs[2] = (CheckBox)findViewById(R.id.sp_checkbox03);
        
       
        //cbs[0].setSelected(true);
        for (int i = 0; i < cbs.length; i++){
        	cbs[i].setChecked(selected[i]);
        }
        
        
        
//        for (int i = 0; i <4; i++){
//        	CHECKBOXES[i] = new CheckBox(this); 
//        	CHECKBOXES[i].setText("hi");
//        }
//        
//        myPlaylists.setAdapter(new ArrayAdapter<CheckBox>(this,android.R.layout.simple_list_item_1, CHECKBOXES));
//        
//        
        Button okButton = (Button)findViewById(R.id.sp_button01);
        
        okButton.setOnClickListener(new View.OnClickListener() {
			
			 

			@Override
			public void onClick(View v) {
				boolean[] selected = new boolean[cbs.length];
				for (int i = 0; i < cbs.length; i++) {
					selected[i] = cbs[i].isChecked();
				}
				Bundle bundle = new Bundle(); 
				
				bundle.putBooleanArray(SELECTED_CBS, selected);
				
                Intent mIntent = new Intent();
                mIntent.putExtras(bundle);
                
                
            	try {
            		OutputStreamWriter out = new OutputStreamWriter(openFileOutput(filename, 0));
            		//out.write(((Boolean)cbs[0].isChecked()).toString());
    				for (int i = 0; i < cbs.length; i++) {
    					out.write(cbs[i].isChecked()?"1":"0");    					
    					//out.write(((Boolean)cbs[i].isChecked()).toString());
    					//System.out.println(cbs[i].isChecked()); 
    				}
            		
            		//out.write(noteField.getText().toString());
            		out.close();
            	}
            	catch (Throwable t) {
            		
            	}
            	
                setResult(RESULT_OK, mIntent);
                
                finish();
			}
		}); 
        
    }
}