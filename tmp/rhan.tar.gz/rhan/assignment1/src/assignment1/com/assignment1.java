/************************************************************************
 * Name: Rhan Kim
 * Date: January 26, 2010
 * Class: Mobile Application Development
 * Program: Basic UI and XML manipulation 
 * Description: This creates an android app that creates a "countdown" to an 
 *   event time that the user can specify.  There are a few glitches.  The 
 *   program assumes that there are always 30 days in a month.
 */
package assignment1.com;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

public class assignment1 extends Activity {
	//////////////////////////////////////////////////////////
	////////////////Fields////////////////////////////////////
	//////////////////////////////////////////////////////////
	private Date target_date; //private fields that keeps track of  
	//the time that the "countdown" is until.

	//////////////////////////////////////////////////////////
	//////////////Method//////////////////////////////////////
	//////////////////////////////////////////////////////////
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		//sets the layout
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main); 
		System.out.println("NEW");
		//creates a listener for the set button and the editText
		final Button btn = (Button)findViewById(R.id.set_button);
		//btn.setEnabled(false); //disable the button until the event has been named
		final EditText name = (EditText)findViewById(R.id.enter_text);
		name.setText("");
		name.setHint("Enter Name");
		System.out.println(name.getText());
		System.out.println("NEW 888 ");
		if(name.getText().length()<=0){
			btn.setEnabled(false);
			
		}else{
			this.changeText();
		}
		//the editText listener makes sure the event is named before the set button 
		//can be clicked
		name.setOnKeyListener(new View.OnKeyListener() {

			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if(name.getText().length()>0){
					btn.setEnabled(true);	
				}
				return false;
			}
		});
		btn.setOnClickListener(new View.OnClickListener() {
			//determines what to do when the set button is clicked
			public void onClick(View v) {
				setFields();
				changeText();
				/*******************************************************************************
				 * This was my attempt at making the program threaded but I had troubles with 
				 * the handlers and so therefore, it is not working, so it is commented out.
 				int delay = 0; // delay for 0 sec.
				int period = 15000; // repeat every 15 sec.
				Timer timer = new Timer();
				timer.scheduleAtFixedRate(new TimerTask() {
					public void run() {					
						//this.cancel();
						//}
					}
				}, delay, period);	
				if(changeText()){
					timer.cancel();
				}
				 ********************************************************************************/
			}
		});
	}
	/*This method changes the text of the UI to reflect the input elements of the UI. */
	public boolean changeText(){
		System.out.println("    HHHHHHHHHHH   ");
		//assigns all of the needed views from the app to a variable for easy location
		TextView event_name = (TextView)findViewById(R.id.event_text);
		EditText name = (EditText)findViewById(R.id.enter_text);
		TextView dhm = (TextView)findViewById(R.id.dhm_text);
		//sets the text area that displays the name of the event by getting the text 
		//from the editText view box.
		System.out.println(name.getText().toString());
		event_name.setText("Time Until " + name.getText().toString());
		//gets the system time and calculates the difference between the current and 
		//time set by the user
		Date current = new Date();
		long difference = target_date.getTime() - current.getTime();
		if (difference<=0){
			//if the time has passed, instead of dealing with negative times, the UI displays
			//that the time has passed
			dhm.setText("Time Has Passed");
			return true;
		}
		else{
			//math to calculate difference in dates.  It assumes that there are
			//always 30 days in a month.
			int dif_min = target_date.getMinutes() - current.getMinutes();
			int dif_hr = target_date.getHours() - current.getHours();
			int dif_day = target_date.getDate() - current.getDate();
			int dif_month = target_date.getMonth() - current.getMonth();
			int dif_yr = target_date.getYear() - current.getYear();
			if (dif_min<0){
				dif_min+=60;
				dif_hr-=1;
			}
			if (dif_hr<0){
				dif_hr+=24;
				dif_day-=1;
			}
			if (dif_day<0){
				dif_day+=30;
				dif_month-=1;
			}
			if (dif_month<0){
				dif_month+=12;
				dif_yr-=1;
			}

			//sets the textfield in the app to display the time differences.
			dhm.setText(dif_yr + " years " + dif_month + " months " + dif_day 
					+ " days " + dif_hr + " hours " + dif_min + " minutes");
			return false;
		}
	}
	/*This method sets all of the fields of the class to values from the app*/
	public void setFields() {
		//assigns all of the needed views from the app to a variable for easy location
		TimePicker time = (TimePicker)findViewById(R.id.time);
		DatePicker date = (DatePicker)findViewById(R.id.date);
		//sets the fieids of the class from the timepicker and the datepicker
		int hour = time.getCurrentHour();
		int min = time.getCurrentMinute();
		int month = date.getMonth();
		int day = date.getDayOfMonth();
		int yr = date.getYear();
		//set the field of the target date to a new Date object
		target_date = new Date(yr-1900, month, day, hour, min, 0);

	}
}

