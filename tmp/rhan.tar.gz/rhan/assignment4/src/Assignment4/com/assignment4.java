/************************************************************************
 * Name: Rhan Kim
 * Date: January 26, 2010
 * Class: Mobile Application Development
 * Program: Basic UI and XML manipulation 
 * Description: This creates an android app that creates a "countdown" to an 
 *   event time that the user can specify.  There are a few glitches.  The 
 *   program assumes that there are always 30 days in a month.
 */
package Assignment4.com;

import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Date;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class assignment4 extends Activity {
	private static final int HELP = 0;
	private static final int WALLPAPER = 1;
	private static final int EXIT = 2;
	private static final int GET_CODE = 3;
	private static final int PUBLIC = 10;
	private static final int OPEN = 12;
	private static final int JELLYFISH = 5;
	private static final int FLOWER = 6;
	private static final int OTHER = 7;
	protected static final String TAG = null;
	private static int counter = 0;
	private Handler handler = new Handler() ;
	private Handler mChildHandler;
	private ChildThread cThread;

	//////////////////////////////////////////////////////////
	////////////////Fields////////////////////////////////////
	//////////////////////////////////////////////////////////
	private Date target_date; //private fields that keeps track of
	private String event_name;
	//the time that the "countdown" is until.
	public static final String PREFS_NAME = "HELLLLO";
	private static final String NOT_FOUND = "not found";
	private static final String SPACER = "\t\t";
	private static final String WP = "get wall paper";
	private int WPAPER = JELLYFISH;
	private final static String NOTES="notes.txt";
	private DBAdapter db;
	private long id;


	//////////////////////////////////////////////////////////
	//////////////Method//////////////////////////////////////
	//////////////////////////////////////////////////////////
	public void onResume() {
		System.out.println("RESUME");
		super.onResume();
		try {
			InputStream in=openFileInput(NOTES);
			if (in!=null) {
				InputStreamReader tmp=new InputStreamReader(in);
				BufferedReader reader=new BufferedReader(tmp);
				String str;
				StringBuilder buf=new StringBuilder();
				while ((str = reader.readLine()) != null) {
					//editor.setText(buf.toString());
					String [] date =str.split(SPACER);
					//System.out.println(date.toString());
					setFields();
					//System.out.println("field");
					this.target_date = new Date(date[1]);
					this.event_name = date[0];
					this.setDate();
					Message msg = mChildHandler.obtainMessage();
					msg.obj = handler.getLooper().getThread().getName() + " says Hello";
					mChildHandler.sendMessage(msg);
					Log.i(TAG, "Send a message to the child thread - " + (String)msg.obj);
					changeText();
					final Button btn = (Button)findViewById(R.id.set_button);
					btn.setEnabled(true);
					System.out.println(str + "    this is being read in");
					setPrevious();
				}
				in.close();


			}
		}
		catch (java.io.FileNotFoundException e) {
			// that's OK, we probably haven't created it yet
		}
		catch (Throwable t) {
			Toast
			.makeText(this, "Exception: "+t.toString(), 2000)
			.show();
		}
	}
	public void onPause() {
		System.out.println("PAUSED");
		super.onPause();
		try {
			OutputStreamWriter out=
				new OutputStreamWriter(openFileOutput(NOTES, 0));

			out.write(this.event_name + this.SPACER+this.target_date.toString());
			System.out.println("writing shitttttttttttttttttttttttttttt");
			//out.write(editor.getText().toString());
			out.close();
		}
		catch (Throwable t) {
			Toast
			.makeText(this, "Exception: "+t.toString(), 2000)
			.show();
		}
	}
	protected void onStop(){
		super.onStop();
	}
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {  
		System.out.println("CREATING");
		//sets the layout
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main); 
		// Restore preferences		
		db = new DBAdapter(this); 	
		
		//System.out.println("NEW");
		//creates a listener for the set button and the editText
		final Button btn = (Button)findViewById(R.id.set_button);

		final EditText name = (EditText)findViewById(R.id.enter_text);

		name.setHint("Enter Name");
		//System.out.println(name.getText());
		//System.out.println("NEW 888 ");
		if(name.getText().length()<=0){
			btn.setEnabled(false);

		}else{
			this.changeText();
		}
		cThread =new ChildThread();
		cThread.start();

		handler = new Handler() {
			public void handleMessage(Message msg) {
				//Log.i(TAG, "Got an incoming message from the child thread - "  + (String)msg.obj);
				changeText();
			}
		};

		//Log.i(TAG, "Main handler is bound to - " + handler.getLooper().getThread().getName());

		name.setOnKeyListener(new View.OnKeyListener() {

			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if(name.getText().length()>0){
					btn.setEnabled(true);	
				}
				return false;
			}
		});
		buttonListener(btn);
		SharedPreferences settings = getSharedPreferences(PREFS_NAME,0);
		int background = settings.getInt(WP, this.JELLYFISH);
		changeWallpaper(background);

	}
	public void buttonListener(Button btn){

		btn.setOnClickListener(new View.OnClickListener() {
			//determines what to do when the set button is clicked
			public void onClick(View v) {
				//handler.getLooper().quit();
				counter = 0;
				Message msg = mChildHandler.obtainMessage();
				msg.obj = handler.getLooper().getThread().getName() + " says Hello";
				mChildHandler.sendMessage(msg);
				//Log.i(TAG, "Send a message to the child thread - " + (String)msg.obj);
				setPrevious();
				setFields();
				changeText();
			}
		});

	}
	@Override
	protected void onDestroy() {
		// Save user preferences. We need an Editor object to
		// make changes. All objects are from android.context.Context
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putInt(WP, this.WPAPER);
		// Don't forget to commit your edits!!!
		editor.commit();

		System.out.println("destrouuuuuuuuuuuuuy");
		/*		try{
			handler.getLooper().quit();
			System.out.print("destroy1");
		}catch(Exception e){
			System.out.println("error caught on DESTORY1");
			Log.e("error", e.toString());
		}*/
		try{
			mChildHandler.getLooper().quit();
			System.out.println("destroy");
		}catch(Exception e){
			System.out.println("error caught on DESTORY2");
		}
		try{
			super.onDestroy();
			System.out.println("Successful destruction");
		}catch(Exception e){
			System.out.println("error caught on DESTORY3");
		}
	}

	/* Creates the menu items */
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, HELP, 0, "Help").setIcon(R.drawable.ic_menu_help);
		menu.add(0, WALLPAPER, 0,"Change Wallpaper").setIcon(R.drawable.ic_menu_gallery);
		menu.add(0, OPEN, 0, "Open Previous").setIcon(R.drawable.ic_menu_archive);
		menu.add(0, EXIT, 0, "Exit").setIcon(R.drawable.ic_menu_close_clear_cancel);
		return true;
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) { 
		//System.out.println("EHLLLO " + GET_CODE + " " + requestCode);
		Bundle b1 = data.getExtras();
		int result2 = b1.getInt("selections");
		//System.out.println("      " + result2);
		if (requestCode == GET_CODE) {		

			//System.out.println(resultCode);
			Bundle b = data.getExtras();
			int result = b.getInt("selections", RESULT_OK);
			//System.out.println("      " + result);
			this.changeWallpaper(result);
		}
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case WALLPAPER:
			System.out.println("WP");
			startActivityForResult(new Intent(this, nextActivity.class),GET_CODE);
			return true;
		case HELP:
			System.out.println("Infomation");
			final Dialog dialog = new Dialog(this); 
			dialog.setContentView(R.layout.help_dialog); 
			dialog.setTitle("HELP VIEW"); 
			dialog.show(); 
			Button buttonOK = (Button) dialog.findViewById(R.id.okay); 
			buttonOK.setOnClickListener(new View.OnClickListener() {
				//determines what to do when the set button is clicked
				public void onClick(View v) {
					System.out.println("cancel");
					dialog.cancel();
				}
			}); 
			return true;
		case EXIT:
			System.out.println("exit");
			this.onDestroy();
			this.finish();
			return true;
		case OPEN:
			System.out.println("public");
			try{
				db.open();
			}catch (SQLException e){
				Toast.makeText(this, "exception in opening", 
						Toast.LENGTH_LONG).show();
			}
			if(id>1)
				id= id-1;
			Cursor c = db.getTitle(id);
			if (c.moveToFirst()){   
				System.out.println("this got throught");
				System.out.println(c.getString(0)+" " +c.getString(1)+" "+c.getString(2));
				this.event_name=c.getString(1);
				System.out.println(c.getString(2));
				Date d = new Date(c.getString(2));
				System.out.println(d);
				this.target_date=d;
				this.setDate();
				this.changeText();
			}else
				Toast.makeText(this, "No title found", 
						Toast.LENGTH_LONG).show();
			db.close();
			return true;
		}
		return false;
	}

	public boolean changeWallpaper(int wallpaper){
		this.WPAPER = wallpaper;
		if (wallpaper == JELLYFISH){
			findViewById(R.id.gen_layout).setBackgroundResource(R.drawable.background);
		}else if (wallpaper == FLOWER){
			findViewById(R.id.gen_layout).setBackgroundResource(R.drawable.flowers);
		}else if (wallpaper == OTHER){
			findViewById(R.id.gen_layout).setBackgroundResource(R.drawable.lighthouse);
		}

		return true;
	}
	/*This method changes the text of the UI to reflect the input elements of the UI. */
	public boolean changeText(){
		//System.out.println("changing text " + counter );
		//assigns all of the needed views from the app to a variable for easy location
		TextView event = (TextView)findViewById(R.id.event_text);
		TextView dhm = (TextView)findViewById(R.id.dhm_text);
		//sets the text area that displays the name of the event by getting the text 
		//from the editText view box.
		event.setText("Time Until " + this.event_name);
		//gets the system time and calculates the difference between the current and 
		//time set by the user
		Date current = new Date();
		//System.out.println(target_date + "         " + current);
		long difference = target_date.getTime() - current.getTime();
		if (difference<=0){
			//if the time has passed, instead of dealing with negative times, the UI displays
			//that the time has passed
			dhm.setText("Time Has Passed");
			return true;
		}
		else{
			//math to calculate difference in dates.  It assumes that there are
			//always 30 days in a month.
			int dif_min = target_date.getMinutes() - current.getMinutes();
			int dif_hr = target_date.getHours() - current.getHours();
			int dif_day = target_date.getDate() - current.getDate();
			int dif_month = target_date.getMonth() - current.getMonth();
			int dif_yr = target_date.getYear() - current.getYear();
			if (dif_min<0){
				dif_min+=60;
				dif_hr-=1;
			}
			if (dif_hr<0){
				dif_hr+=24;
				dif_day-=1;
			}
			if (dif_day<0){
				dif_day+=30;
				dif_month-=1;
			}
			if (dif_month<0){
				dif_month+=12;
				dif_yr-=1;
			}

			//sets the textfield in the app to display the time differences.
			dhm.setText(dif_yr + " years " + dif_month + " months " + dif_day 
					+ " days " + dif_hr + " hours " + dif_min + " minutes");
			return false;
		}
	}
	
	public void setPrevious(){
		System.out.println("make public");
		System.out.println(db);
		db.open();
		id = db.insertTitle(
				this.event_name,this.target_date.toString());
		System.out.println(id+ " this is the ID");
		db.close();
	}
	/*This method sets all of the fields of the class to values from the app*/
	public void setFields() {
		//System.out.println("hello");
		//assigns all of the needed views from the app to a variable for easy location
		TimePicker time = (TimePicker)findViewById(R.id.time);
		DatePicker date = (DatePicker)findViewById(R.id.date);
		//sets the fieids of the class from the timepicker and the datepicker
		int hour = time.getCurrentHour();
		int min = time.getCurrentMinute();
		int month = date.getMonth();
		int day = date.getDayOfMonth();
		int yr = date.getYear();
		//set the field of the target date to a new Date object
		target_date = new Date(yr-1900, month, day, hour, min, 0);
		EditText name = (EditText)findViewById(R.id.enter_text);
		this.event_name = name.getText().toString();
		
	}

	public void setDate() {
		System.out.println("setdate");
		//assigns all of the needed views from the app to a variable for easy location
		TimePicker time = (TimePicker)findViewById(R.id.time);
		DatePicker date = (DatePicker)findViewById(R.id.date);
		//sets the fieids of the class from the timepicker and the datepicker
		int hour = this.target_date.getHours();
		int min = target_date.getMinutes();
		int month = target_date.getMonth();
		int day = target_date.getDate();
		int yr = target_date.getYear()+1900;
		//set the field of the target date to a new Date object
		time.setCurrentHour(hour);
		time.setCurrentMinute(min);
		date.updateDate(yr, month, day);
		EditText name = (EditText)findViewById(R.id.enter_text);
		name.setText(this.event_name);
	}


	class ChildThread extends Thread {

		private static final String INNER_TAG = "ChildThread";

		public void run() {

			this.setName("child");
			Looper.prepare();
			mChildHandler = new Handler(){

				public void handleMessage(Message msg) {
					//Log.i(INNER_TAG, "Got an incoming message from the main thread - " + (String)msg.obj);
					try{
						int delay = 0;   // delay for 0 sec.
						int period = 10000;  // repeat every 10 sec.
						Timer timer = new Timer();
						timer.scheduleAtFixedRate(new TimerTask() {
							public void run() {					
								Message toMain = handler.obtainMessage();
								toMain.obj = "It is time to change text";
								handler.sendMessage(toMain);
							}
						}, delay, period);
					}catch (Exception e) {
						Log.d("errors", msg.toString());
						e.printStackTrace();
					}
				}
			};

			//Log.i(INNER_TAG, "Child handler is bound to - " + mChildHandler.getLooper().getThread().getName());

			/*
			 * Start looping the message queue of this thread.
			 */
			Looper.loop();
		}
	}

}

