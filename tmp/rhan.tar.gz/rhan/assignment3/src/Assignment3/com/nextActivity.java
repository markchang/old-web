/************************************************************************
 * Name: Rhan Kim
 * Date: January 26, 2010
 * Class: Mobile Application Development
 * Program: Basic UI and XML manipulation 
 * Description: This creates an android app that creates a "countdown" to an 
 *   event time that the user can specify.  There are a few glitches.  The 
 *   program assumes that there are always 30 days in a month.
 */

package Assignment3.com;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class nextActivity extends Activity{
	private static final int JELLYFISH = 5;
	private static final int FLOWER = 6;
	private static final int OTHER = 7;
	//////////////////////////////////////////////////////////
	//////////////Method//////////////////////////////////////
	//////////////////////////////////////////////////////////
	/** Called when the activity is first created. */
	public void onCreate(Bundle savedInstanceState) {
		//sets the layout
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity2); 

		final Button btn = (Button)findViewById(R.id.done);

		btn.setOnClickListener(new View.OnClickListener() {
			//determines what to do when the set button is clicked
			public void onClick(View v) {
				Bundle bundle = new Bundle();
				System.out.println("RESULT   "+getInfo());
				bundle.putInt("selections",getInfo());
				Intent resultIntent = new Intent();
				resultIntent.putExtras(bundle);
				setResult(RESULT_OK, resultIntent);
				System.out.println("DONE");
				System.out.println(resultIntent.getExtras().getInt("selections",RESULT_OK));
				finish();
			}
		});

	}
	public int getInfo(){
		RadioGroup group =(RadioGroup)findViewById(R.id.RGroup);
		int checkedId=group.getCheckedRadioButtonId();
		if (checkedId == R.id.JFish){
			//setResult(RESULT_OK, (new Intent()).setFlags(JELLYFISH));
			return JELLYFISH;
		}else if (checkedId == R.id.FLWR){
			//setResult(RESULT_OK, (new Intent()).setFlags(FLOWER));
			return FLOWER;
		}else if (checkedId == R.id.OTHR){
			//setResult(RESULT_OK, (new Intent()).setFlags(OTHER));
			return OTHER;
		}
		return 0;
	}

}




