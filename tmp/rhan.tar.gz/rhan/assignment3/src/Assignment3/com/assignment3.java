/************************************************************************
 * Name: Rhan Kim
 * Date: January 26, 2010
 * Class: Mobile Application Development
 * Program: Basic UI and XML manipulation 
 * Description: This creates an android app that creates a "countdown" to an 
 *   event time that the user can specify.  There are a few glitches.  The 
 *   program assumes that there are always 30 days in a month.
 */
package Assignment3.com;


import java.util.Date;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

public class assignment3 extends Activity {
	private static final int HELP = 0;
	private static final int WALLPAPER = 1;
	private static final int EXIT = 2;
	private static final int GET_CODE = 3;

	private static final int JELLYFISH = 5;
	private static final int FLOWER = 6;
	private static final int OTHER = 7;
	protected static final String TAG = null;
	private static int counter = 0;
	private Handler handler = new Handler() ;
	private Handler mChildHandler;
	private ChildThread cThread;

	//////////////////////////////////////////////////////////
	////////////////Fields////////////////////////////////////
	//////////////////////////////////////////////////////////
	private Date target_date; //private fields that keeps track of  
	//the time that the "countdown" is until.

	//////////////////////////////////////////////////////////
	//////////////Method//////////////////////////////////////
	//////////////////////////////////////////////////////////
	public void onResume(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		System.out.println("on resuming");
	}
	public void onPause(Bundle savedInstanceState){
		super.onDestroy();
	}

/*	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) 
	{

		//---retrieve the information persisted earlier---
		TimePicker time = (TimePicker)findViewById(R.id.time);
		DatePicker date = (DatePicker)findViewById(R.id.date);
		time.setCurrentHour(this.target_date.getHours());
		time.setCurrentMinute(this.target_date.getMinutes());
		date.updateDate(this.target_date.getYear()+1900, this.target_date.getMonth(), this.target_date.getDate());
		super.onRestoreInstanceState(savedInstanceState);
	}*/
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		//sets the layout
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main); 
		System.out.println("NEW");
		//creates a listener for the set button and the editText
		final Button btn = (Button)findViewById(R.id.set_button);
		//btn.setEnabled(false); //disable the button until the event has been named
		final EditText name = (EditText)findViewById(R.id.enter_text);
		name.setText("");
		name.setHint("Enter Name");
		System.out.println(name.getText());
		System.out.println("NEW 888 ");
		if(name.getText().length()<=0){
			btn.setEnabled(false);

		}else{
			this.changeText();
		}
		cThread =new ChildThread();
		cThread.start();

		handler = new Handler() {
			public void handleMessage(Message msg) {
				Log.i(TAG, "Got an incoming message from the child thread - "  + (String)msg.obj);
				changeText();
			}
		};

		Log.i(TAG, "Main handler is bound to - " + handler.getLooper().getThread().getName());

		name.setOnKeyListener(new View.OnKeyListener() {

			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if(name.getText().length()>0){
					btn.setEnabled(true);	
				}
				return false;
			}
		});
		buttonListener(btn);
	}
	public void buttonListener(Button btn){

		btn.setOnClickListener(new View.OnClickListener() {
			//determines what to do when the set button is clicked
			public void onClick(View v) {
				//handler.getLooper().quit();
				counter = 0;
				Message msg = mChildHandler.obtainMessage();
				msg.obj = handler.getLooper().getThread().getName() + " says Hello";
				mChildHandler.sendMessage(msg);
				Log.i(TAG, "Send a message to the child thread - " + (String)msg.obj);
				setFields();
				changeText();

			}
		});

	}
	@Override
	protected void onDestroy() {
		//cThread.stop();
		System.out.println("destrouuuuuuuuuuuuuy");
/*		try{
			handler.getLooper().quit();
			System.out.print("destroy1");
		}catch(Exception e){
			System.out.println("error caught on DESTORY1");
			Log.e("error", e.toString());
		}*/
		try{
			mChildHandler.getLooper().quit();
			System.out.println("destroy");
		}catch(Exception e){
			System.out.println("error caught on DESTORY2");
		}
		try{
			super.onDestroy();
			System.out.println("Successful destruction");
		}catch(Exception e){
			System.out.println("error caught on DESTORY3");
		}
	}

	/* Creates the menu items */
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, HELP, 0, "Help").setIcon(R.drawable.ic_menu_help);
		menu.add(0, WALLPAPER, 0,"Change Wallpaper").setIcon(R.drawable.ic_menu_gallery);
		menu.add(0, EXIT, 0, "Exit").setIcon(R.drawable.ic_menu_close_clear_cancel);
		return true;
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) { 
		System.out.println("EHLLLO " + GET_CODE + " " + requestCode);
		Bundle b1 = data.getExtras();
		int result2 = b1.getInt("selections");
		System.out.println("      " + result2);
		if (requestCode == GET_CODE) {		

			System.out.println(resultCode);
			Bundle b = data.getExtras();
			int result = b.getInt("selections", RESULT_OK);
			System.out.println("      " + result);
			this.changeWallpaper(result);
		}
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case WALLPAPER:
			System.out.println("WP");
			startActivityForResult(new Intent(this, nextActivity.class),GET_CODE);
			return true;
		case HELP:
			System.out.println("Infomation");
			final Dialog dialog = new Dialog(this); 
			dialog.setContentView(R.layout.help_dialog); 
			dialog.setTitle("HELP VIEW"); 
			dialog.show(); 
			Button buttonOK = (Button) dialog.findViewById(R.id.okay); 
			buttonOK.setOnClickListener(new View.OnClickListener() {
				//determines what to do when the set button is clicked
				public void onClick(View v) {
					System.out.println("cancel");
					dialog.cancel();
				}
			}); 
			return true;
		case EXIT:
			System.out.println("exit");
			this.finish();
			return true;
		}
		return false;
	}

	public boolean changeWallpaper(int wallpaper){
		if (wallpaper == JELLYFISH){
			findViewById(R.id.gen_layout).setBackgroundResource(R.drawable.background);
		}else if (wallpaper == FLOWER){
			findViewById(R.id.gen_layout).setBackgroundResource(R.drawable.flowers);
		}else if (wallpaper == OTHER){
			findViewById(R.id.gen_layout).setBackgroundResource(R.drawable.lighthouse);
		}

		return true;
	}
	/*This method changes the text of the UI to reflect the input elements of the UI. */
	public boolean changeText(){


		System.out.println("changing text " + counter );
		//assigns all of the needed views from the app to a variable for easy location
		TextView event_name = (TextView)findViewById(R.id.event_text);
		EditText name = (EditText)findViewById(R.id.enter_text);
		TextView dhm = (TextView)findViewById(R.id.dhm_text);
		//sets the text area that displays the name of the event by getting the text 
		//from the editText view box.
		System.out.println(name.getText().toString());
		event_name.setText("Time Until " + name.getText().toString());
		//gets the system time and calculates the difference between the current and 
		//time set by the user
		Date current = new Date();
		long difference = target_date.getTime() - current.getTime();
		if (difference<=0){
			//if the time has passed, instead of dealing with negative times, the UI displays
			//that the time has passed
			dhm.setText("Time Has Passed");
			return true;
		}
		else{
			//math to calculate difference in dates.  It assumes that there are
			//always 30 days in a month.
			int dif_min = target_date.getMinutes() - current.getMinutes();
			int dif_hr = target_date.getHours() - current.getHours();
			int dif_day = target_date.getDate() - current.getDate();
			int dif_month = target_date.getMonth() - current.getMonth();
			int dif_yr = target_date.getYear() - current.getYear();
			if (dif_min<0){
				dif_min+=60;
				dif_hr-=1;
			}
			if (dif_hr<0){
				dif_hr+=24;
				dif_day-=1;
			}
			if (dif_day<0){
				dif_day+=30;
				dif_month-=1;
			}
			if (dif_month<0){
				dif_month+=12;
				dif_yr-=1;
			}

			//sets the textfield in the app to display the time differences.
			dhm.setText(dif_yr + " years " + dif_month + " months " + dif_day 
					+ " days " + dif_hr + " hours " + dif_min + " minutes");
			return false;
		}
	}
	/*This method sets all of the fields of the class to values from the app*/
	public void setFields() {
		System.out.println("hello");
		//assigns all of the needed views from the app to a variable for easy location
		TimePicker time = (TimePicker)findViewById(R.id.time);
		DatePicker date = (DatePicker)findViewById(R.id.date);
		//sets the fieids of the class from the timepicker and the datepicker
		int hour = time.getCurrentHour();
		int min = time.getCurrentMinute();
		int month = date.getMonth();
		int day = date.getDayOfMonth();
		int yr = date.getYear();
		//set the field of the target date to a new Date object
		target_date = new Date(yr-1900, month, day, hour, min, 0);

	}

	class ChildThread extends Thread {

		private static final String INNER_TAG = "ChildThread";

		public void run() {

			this.setName("child");
			Looper.prepare();
			mChildHandler = new Handler(){

				public void handleMessage(Message msg) {
					Log.i(INNER_TAG, "Got an incoming message from the main thread - " + (String)msg.obj);
					try{
						int delay = 0;   // delay for 5 sec.
						int period = 5000;  // repeat every 1 sec.
						Timer timer = new Timer();
						timer.scheduleAtFixedRate(new TimerTask() {
							public void run() {					
								Message toMain = handler.obtainMessage();
								toMain.obj = "It is time to change text";
								handler.sendMessage(toMain);
							}
						}, delay, period);
					}catch (Exception e) {
						Log.d("errors", msg.toString());
						e.printStackTrace();
					}
				}
			};

			Log.i(INNER_TAG, "Child handler is bound to - " + mChildHandler.getLooper().getThread().getName());

			/*
			 * Start looping the message queue of this thread.
			 */
			Looper.loop();
		}
	}

}

